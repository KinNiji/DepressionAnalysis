#! /usr/bin/env python
# -*- coding: UTF-8 -*-

import json
from abc import ABCMeta, abstractmethod
from enum import Enum

from .SchemaId import SchemaId


class ISchemaSupport(metaclass=ABCMeta):
    """
    schema interface: all schema must implements it
    """

    @abstractmethod
    def getSchemaId(self) -> SchemaId:
        """
        get schema id
        :return:  schema id
        """
        pass

    def dumps(self) -> str:
        """
        format current object to json str
        :return: json str
        """

        # schemaId do not needed
        copy_dict = self.__dict__.copy()

        ISchemaSupport.__prepare(copy_dict)

        return json.dumps(copy_dict)

    def dict(self):
        """
        transfomr to json object
        :return:
        """
        copy_dict = self.__dict__.copy()
        ISchemaSupport.__prepare(copy_dict)
        return copy_dict

    @staticmethod
    def __prepare(data_dict: dict):
        # delete none field
        ISchemaSupport.__del_none_field(data_dict)

        for key, value in list(data_dict.items()):
            if key.find("__schemaId") >= 0:
                data_dict.pop(key)
                continue

            if ISchemaSupport.__is_simple_type(value):
                continue

            if isinstance(value, list):
                data_dict[key] = []
                if len(value) > 0:
                    for item in value:
                        if ISchemaSupport.__is_simple_type(item):
                            data_dict[key].append(item)
                        else:
                            item_dict = item.__dict__
                            ISchemaSupport.__prepare(item_dict)
                            data_dict[key].append(item_dict)
                continue

            if isinstance(value, Enum):
                data_dict[key] = value.value
                continue

            data_dict[key] = value.__dict__

            ISchemaSupport.__prepare(value.__dict__)

    @staticmethod
    def __del_none_field(data):
        for key, value in list(data.items()):
            if value is None:
                del data[key]
            elif isinstance(value, dict):
                ISchemaSupport.__del_none_field(value)

    @staticmethod
    def __is_simple_type(value):
        return True if (isinstance(value, int) or isinstance(value, str) or isinstance(value, float) \
                        or isinstance(value, dict) or isinstance(value, tuple)) else False
