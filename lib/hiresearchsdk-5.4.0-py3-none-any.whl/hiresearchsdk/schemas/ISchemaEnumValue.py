#! /usr/bin/env python
# -*- coding: UTF-8 -*-

from abc import ABCMeta, abstractmethod


class ISchemaEnumValue(metaclass=ABCMeta):
    """
    schema enum interface
    """

    @abstractmethod
    def getSchemaValue(self) -> str:
        """
        get schema enum value
        :return:  schema enum value
        """
        pass
