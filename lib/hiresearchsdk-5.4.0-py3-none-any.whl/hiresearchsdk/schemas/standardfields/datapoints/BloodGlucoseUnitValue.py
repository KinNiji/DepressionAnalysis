#! /usr/bin/env python
# -*- coding: UTF-8 -*-
from ...basictypes import UnitValue
from ...units import BloodGlucoseUnit


class BloodGlucoseUnitValue(UnitValue):
    """
    blood glucose unitvalue definition
    """

    def __init__(self, value: float, unit: BloodGlucoseUnit):
        """
        create a datapoint
        :param value: must be float
        :param unit: must be BloodGlucoseUnit
        """

        super(BloodGlucoseUnitValue, self).__init__(value, unit)
