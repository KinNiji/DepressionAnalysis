#! /usr/bin/env python
# -*- coding: UTF-8 -*-

from ...basictypes import UnitValue
from ...units import CurrentUnit


class CurrentUnitValue(UnitValue):
    """
    current velocity unitvalue definition
    """

    def __init__(self, value: float, unit: CurrentUnit):
        """
        create a datapoint
        :param value: value
        :param unit: must be CurrentUnit
        """

        super(CurrentUnitValue, self).__init__(value, unit)