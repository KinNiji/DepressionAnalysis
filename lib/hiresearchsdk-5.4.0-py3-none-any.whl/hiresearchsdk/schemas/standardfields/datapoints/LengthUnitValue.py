#! /usr/bin/env python
# -*- coding: UTF-8 -*-

from ...basictypes import UnitValue
from ...units import LengthUnit


class LengthUnitValue(UnitValue):
    """
    length unitvalue definition
    """

    def __init__(self, value: any, unit: LengthUnit):
        """
        create a unitvalue
        :param value: value
        :param unit: must be LengthUnit
        """

        super(LengthUnitValue, self).__init__(value, unit)


class LengthUnitValueFactory(object):
    """
    datapoint factory
    """

    @staticmethod
    def newFloatUnitValue(value: float, unit: LengthUnit = None) -> LengthUnitValue:
        """
        create datapoint with a float value
        :param value: must be float
        :param unit: must be LengthUnit
        :return:
        """
        return LengthUnitValue(value, unit)

    @staticmethod
    def newIntUnitValue(value: int, unit: LengthUnit = None) -> LengthUnitValue:
        """
        create datapoint with a int value
        :param value: must be int
        :param unit: must be LengthUnit
        :return:
        """
        return LengthUnitValue(value, unit)
