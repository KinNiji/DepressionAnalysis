#! /usr/bin/env python
# -*- coding: UTF-8 -*-

from ...basictypes import UnitValue
from ...units import DurationUnit


class RRIUnitValue(UnitValue):
    """
    rri unitvalue definition
    """

    def __init__(self, value: float, unit: DurationUnit = None):
        """
        create a unitvalue
        :param value: must be float
        :param unit: must be DurationUnit
        """
        if unit is None:
            unit = DurationUnit.MILLISECOND

        super(RRIUnitValue, self).__init__(value, unit)
