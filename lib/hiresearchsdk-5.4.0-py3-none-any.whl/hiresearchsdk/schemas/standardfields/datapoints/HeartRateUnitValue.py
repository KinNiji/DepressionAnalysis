#! /usr/bin/env python
# -*- coding: UTF-8 -*-

from ...basictypes import UnitValue
from ...units import HeartRateUnit


class HeartRateUnitValue(UnitValue):
    """
    heartrate unitvalue definition
    """

    def __init__(self, value: any, unit: HeartRateUnit):
        """
        create a unitvalue
        :param value: value
        :param unit: must be HeartRateUnit
        """
        if unit is None:
            unit = HeartRateUnit.BEATS_PER_MINUTE

        super(HeartRateUnitValue, self).__init__(value, unit)


class HeartRateUnitValueFactory(object):
    """
    datapoint factory
    """

    @staticmethod
    def newFloatUnitValue(value: float, unit: HeartRateUnit = None) -> HeartRateUnitValue:
        """
        create datapoint with a float value
        :param value: must be float
        :param unit: must be HeartRateUnit
        :return:
        """
        return HeartRateUnitValue(value, unit)

    @staticmethod
    def newIntUnitValue(value: int, unit: HeartRateUnit = None) -> HeartRateUnitValue:
        """
        create datapoint with a int value
        :param value: must be int
        :param unit: must be HeartRateUnit
        :return:
        """
        return HeartRateUnitValue(value, unit)
