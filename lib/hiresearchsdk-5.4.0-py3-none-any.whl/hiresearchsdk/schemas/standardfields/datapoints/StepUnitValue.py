#! /usr/bin/env python
# -*- coding: UTF-8 -*-

from ...basictypes import UnitValue
from ...units import StepUnit


class StepUnitValue(UnitValue):
    """
    step unitvalue definition
    """

    def __init__(self, value: int, unit: StepUnit):
        """
        create a unitvalue
        :param value: value
        :param unit: must be StepUnit
        """
        if unit is None:
            unit = StepUnit.STEPS_OF_UNIT

        super(StepUnitValue, self).__init__(value, unit)