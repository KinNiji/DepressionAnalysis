#! /usr/bin/env python
# -*- coding: UTF-8 -*-

from ...basictypes import UnitValue
from ...units import VoltageUnit


class VoltageUnitValue(UnitValue):
    """
    voltage unitvalue definition
    """

    def __init__(self, value: float, unit: VoltageUnit):
        """
        create a unitvalue
        :param value: value
        :param unit: must be AngularVelocityUnit
        """

        super(VoltageUnitValue, self).__init__(value, unit)