#! /usr/bin/env python
# -*- coding: UTF-8 -*-
from ...basictypes import UnitValue
from ...units import BloodPressureUnit


class BloodPressureUnitValue(UnitValue):
    """
    blood pressure unitvalue definition
    """

    def __init__(self, value: float, unit: BloodPressureUnit = None):
        """
        create a datapoint
        :param value: must be float
        :param unit: must be BloodPressureUnit
        """

        if unit is None:
            unit = BloodPressureUnit.MM_OF_MERCURY

        super(BloodPressureUnitValue, self).__init__(value, unit)
