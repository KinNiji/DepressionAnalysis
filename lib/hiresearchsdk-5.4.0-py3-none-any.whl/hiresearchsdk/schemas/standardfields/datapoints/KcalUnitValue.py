#! /usr/bin/env python
# -*- coding: UTF-8 -*-

from ...basictypes import UnitValue
from ...units import KcalUnit


class KcalUnitValue(UnitValue):
    """
    calories burned unitvalue definition
    """

    def __init__(self, value: float, unit: KcalUnit = None):
        """
        create a unitvalue
        :param value: must be float
        :param unit: must be KcalUnit
        """

        if unit is None:
            unit = KcalUnit.KILOCALORIE

        super(KcalUnitValue, self).__init__(value, unit)
