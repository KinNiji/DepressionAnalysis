#! /usr/bin/env python
# -*- coding: UTF-8 -*-

from ...basictypes import UnitValue
from ...units import MassUnit


class MassUnitValue(UnitValue):
    """
    mass unitvalue definition
    """

    def __init__(self, value: any, unit: MassUnit):
        """
        create a unitvalue
        :param value: value
        :param unit: must be MassUnit
        """

        super(MassUnitValue, self).__init__(value, unit)


class MassUnitValueFactory(object):
    """
    datapoint factory
    """

    @staticmethod
    def newFloatUnitValue(value: float, unit: MassUnit = None) -> MassUnitValue:
        """
        create datapoint with a float value
        :param value: must be float
        :param unit: must be MassUnit
        :return:
        """
        return MassUnitValue(value, unit)

    @staticmethod
    def newIntUnitValue(value: int, unit: MassUnit = None) -> MassUnitValue:
        """
        create datapoint with a int value
        :param value: must be int
        :param unit: must be MassUnit
        :return:
        """
        return MassUnitValue(value, unit)
