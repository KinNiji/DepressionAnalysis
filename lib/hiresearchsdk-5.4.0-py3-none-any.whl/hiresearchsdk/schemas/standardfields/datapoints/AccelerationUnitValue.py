#! /usr/bin/env python
# -*- coding: UTF-8 -*-

from ...basictypes import UnitValue
from ...units import AccelerationUnit


class AccelerationUnitValue(UnitValue):
    """
    acceleration unitvalue definition
    """

    def __init__(self, value: float, unit: AccelerationUnit):
        """
        create a datapoint
        :param value: value
        :param unit: must be AccelerationUnit
        """
        if unit is None:
            unit = AccelerationUnit.MS_OF_ACCELERATION

        super(AccelerationUnitValue, self).__init__(value, unit)