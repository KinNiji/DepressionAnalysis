#! /usr/bin/env python
# -*- coding: UTF-8 -*-

from ...basictypes import UnitValue
from ...units import DurationUnit


class DurationUnitValue(UnitValue):
    """
    calories burned unitvalue definition
    """

    def __init__(self, value: any, unit: DurationUnit):
        """
        create a unitvalue
        :param value: value
        :param unit: must be DurationUnit
        """

        super(DurationUnitValue, self).__init__(value, unit)


class DurationUnitValueFactory(object):
    """
    datapoint factory
    """

    @staticmethod
    def newFloatUnitValue(value: float, unit: DurationUnit) -> DurationUnitValue:
        """
        create datapoint with a float value
        :param value: must be float
        :param unit: must be DurationUnit
        :return:
        """
        return DurationUnitValue(value, unit)

    @staticmethod
    def newIntUnitValue(value: int, unit: DurationUnit) -> DurationUnitValue:
        """
        create datapoint with a int value
        :param value: must be int
        :param unit: must be DurationUnit
        :return:
        """
        return DurationUnitValue(value, unit)
