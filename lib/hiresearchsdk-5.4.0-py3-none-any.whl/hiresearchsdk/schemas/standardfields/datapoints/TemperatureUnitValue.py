#! /usr/bin/env python
# -*- coding: UTF-8 -*-

from ...basictypes import UnitValue
from ...units import TemperatureUnit


class TemperatureUnitValue(UnitValue):
    """
    temperature unitvalue definition
    """

    def __init__(self, value: float, unit: TemperatureUnit):
        """
        create a unitvalue
        :param value: value
        :param unit: must be TemperatureUnit
        """

        super(TemperatureUnitValue, self).__init__(value, unit)