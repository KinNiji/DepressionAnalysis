#! /usr/bin/env python
# -*- coding: UTF-8 -*-
from ..unitvalue import KcalUnitValue

from ...Measure import Measure
from ...SchemaId import SchemaId
from ...basictypes import TimeFrame
from ...enums import DescriptiveStatistic, Namespace, DescriptiveStatisticDenominator


class CaloriesBurned(Measure):
    """
    calories burned definition
    """

    def __init__(self, caloriesBurned: KcalUnitValue,
                 activityName: str = None,
                 descriptiveStatisticDenominator: DescriptiveStatisticDenominator = None,
                 timeFrame: TimeFrame = None,
                 descriptiveStatistic: DescriptiveStatistic = None,
                 userNotes: str = None):
        """
        create calories burned bean
        :param calories_burned: calories burned data point
        :param activity_name: activity name
        :param descriptive_statistics_denominator: descriptive statistics denominator
        :param time_frame: time frame
        :param descriptive_statistics: description statistics
        :param userNotes: user notes
        """
        super(CaloriesBurned, self).__init__(timeFrame, descriptiveStatistic, userNotes)

        self.__schemaId = SchemaId(Namespace.NAMESPACE_SPORTS, "CaloriesBurned")

        self.caloriesBurned = caloriesBurned
        self.activityName = activityName
        self.descriptiveStatisticDenominator = descriptiveStatisticDenominator
        self.timeFrame = timeFrame
        self.descriptiveStatistic = descriptiveStatistic
        self.userNotes = userNotes

    def getCaloriesBurned(self) -> KcalUnitValue:
        return self.caloriesBurned

    def getActivityName(self) -> str:
        return self.activityName

    def getDescriptiveStatisticDenominator(self) -> str:
        return self.descriptiveStatisticDenominator

    def getSchemaId(self) -> SchemaId:
        return self.__schemaId

    @classmethod
    def from_json(cls, json_data: dict):
        caloriesBurned = KcalUnitValue(json_data.get("caloriesBurned"))
        activityName = json_data.get("activityName")
        descriptiveStatisticDenominator = DescriptiveStatisticDenominator(
            json_data.get("descriptiveStatisticDenominator")) if json_data.get(
            "descriptiveStatisticDenominator") is not None else None
        timeFrame = TimeFrame(json_data.get("timeFrame"))
        descriptiveStatistic = DescriptiveStatistic(json_data.get("descriptiveStatistic")) if json_data.get(
            "descriptiveStatistic") is not None else None
        userNotes = json_data.get("userNotes")

        return cls(caloriesBurned=caloriesBurned,
                   activityName=activityName,
                   descriptiveStatisticDenominator=descriptiveStatisticDenominator,
                   timeFrame=timeFrame,
                   descriptiveStatistic=descriptiveStatistic,
                   userNotes=userNotes)
