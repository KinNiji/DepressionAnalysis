#! /usr/bin/env python
# -*- coding: UTF-8 -*-
from ..unitvalue import LengthUnitValue

from ...Measure import Measure
from ...SchemaId import SchemaId
from ...basictypes import TimeFrame
from ...enums import DescriptiveStatistic, Namespace, DescriptiveStatisticDenominator


class Distance(Measure):
    """
    distance definition
    """

    def __init__(self, distance: LengthUnitValue,
                 descriptiveStatisticDenominator: DescriptiveStatisticDenominator = None,
                 timeFrame: TimeFrame = None, descriptiveStatistic: DescriptiveStatistic = None,
                 userNotes: str = None):
        """
        create distance bean
        :param distance: distance data point
        :param descriptive_statistics_denominator: descriptive statistics denominator
        :param time_frame: time frame
        :param descriptive_statistics: description statistics
        :param userNotes: user notes
        """
        super(Distance, self).__init__(timeFrame, descriptiveStatistic, userNotes)

        self.__schemaId = SchemaId(Namespace.NAMESPACE_SPORTS, "Distance")

        self.distance = distance
        self.descriptiveStatisticDenominator = descriptiveStatisticDenominator
        self.timeFrame = timeFrame
        self.descriptiveStatistic = descriptiveStatistic
        self.userNotes = userNotes

    def getDistance(self) -> LengthUnitValue:
        return self.distance

    def getDescriptiveStatisticDenominator(self) -> str:
        return self.descriptiveStatisticDenominator.value

    def getSchemaId(self) -> SchemaId:
        return self.__schemaId

    @classmethod
    def from_json(cls, json_data: dict):
        distance = LengthUnitValue(json_data.get("distance"))
        descriptiveStatisticDenominator = DescriptiveStatisticDenominator(
            json_data.get("descriptiveStatisticDenominator")) if json_data.get(
            "descriptiveStatisticDenominator") is not None else None
        timeFrame = TimeFrame(json_data.get("timeFrame"))
        descriptiveStatistic = DescriptiveStatistic(json_data.get("descriptiveStatistic")) if json_data.get(
            "descriptiveStatistic") is not None else None
        userNotes = json_data.get("userNotes")

        return cls(distance=distance,
                   descriptiveStatisticDenominator=descriptiveStatisticDenominator,
                   timeFrame=timeFrame,
                   descriptiveStatistic=descriptiveStatistic,
                   userNotes=userNotes)
