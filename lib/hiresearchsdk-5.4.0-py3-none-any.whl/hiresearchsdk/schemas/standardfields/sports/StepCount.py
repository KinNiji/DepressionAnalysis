#! /usr/bin/env python
# -*- coding: UTF-8 -*-

from ..unitvalue import StepUnitValue
from ...Measure import Measure
from ...SchemaId import SchemaId
from ...basictypes import TimeFrame
from ...enums import DescriptiveStatistic, Namespace, DescriptiveStatisticDenominator


class StepCount(Measure):
    """
    step count definition
    """

    def __init__(self, stepCount: StepUnitValue,
                 descriptiveStatisticDenominator: DescriptiveStatisticDenominator = None,
                 timeframe: TimeFrame = None, descriptiveStatistic: DescriptiveStatistic = None,
                 userNotes: str = None):
        """
        create step count bean
        :param step_count: step counts data point
        :param descriptive_statistics_denominator: descriptive statistics denominator
        :param time_frame: time frame
        :param descriptive_statistics: description statistics
        :param userNotes: user notes
        """
        super(StepCount, self).__init__(timeframe, descriptiveStatistic, userNotes)

        self.__schemaId = SchemaId(Namespace.NAMESPACE_SPORTS, "StepCount")

        self.stepCount = stepCount
        self.descriptiveStatisticDenominator = descriptiveStatisticDenominator
        self.timeFrame = timeframe
        self.descriptiveStatistic = descriptiveStatistic
        self.userNotes = userNotes

    def getStepCount(self) -> StepUnitValue:
        return self.stepCount

    def getDescriptiveStatisticDenominator(self) -> str:
        return self.descriptiveStatisticDenominator.value

    def getSchemaId(self) -> SchemaId:
        return self.__schemaId

    @classmethod
    def from_json(cls, json_data: dict):
        stepCount = StepUnitValue(json_data.get("stepCount"))
        descriptiveStatisticDenominator = DescriptiveStatisticDenominator(
            json_data.get("descriptiveStatisticDenominator")) if json_data.get(
            "descriptiveStatisticDenominator") is not None else None
        timeframe = TimeFrame(json_data.get("timeFrame"))
        descriptiveStatistic = DescriptiveStatistic(json_data.get("descriptiveStatistic")) if json_data.get(
            "descriptiveStatistic") is not None else None
        userNotes = json_data.get("userNotes")

        return cls(stepCount=stepCount,
                   descriptiveStatisticDenominator=descriptiveStatisticDenominator,
                   timeframe=timeframe,
                   descriptiveStatistic=descriptiveStatistic,
                   userNotes=userNotes)
