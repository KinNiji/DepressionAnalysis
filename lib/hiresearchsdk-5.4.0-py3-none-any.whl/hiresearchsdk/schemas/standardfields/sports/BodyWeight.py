#! /usr/bin/env python
# -*- coding: UTF-8 -*-
from ..unitvalue import MassUnitValue

from ...Measure import Measure
from ...SchemaId import SchemaId
from ...basictypes import TimeFrame
from ...enums import DescriptiveStatistic, Namespace


class BodyWeight(Measure):
    """
    body weight definition
    """

    def __init__(self, bodyWeight: MassUnitValue,
                 timeFrame: TimeFrame = None, descriptiveStatistic: DescriptiveStatistic = None,
                 userNotes: str = None):
        """
        create body weight bean
        :param body_weight: body weight
        :param time_frame: time frame
        :param descriptive_statistics: description statistics
        :param userNotes: user notes
        """
        super(BodyWeight, self).__init__(timeFrame, descriptiveStatistic, userNotes)

        self.__schemaId = SchemaId(Namespace.NAMESPACE_SPORTS, "BodyWeight")

        self.bodyWeight = bodyWeight
        self.timeFrame = timeFrame
        self.descriptiveStatistic = descriptiveStatistic
        self.userNotes = userNotes

    def getBodyWeight(self) -> MassUnitValue:
        return self.bodyWeight

    def getSchemaId(self) -> SchemaId:
        return self.__schemaId

    @classmethod
    def from_json(cls, json_data: dict):
        bodyWeight = MassUnitValue(json_data.get("bodyWeight"))
        timeFrame = TimeFrame(json_data.get("timeFrame"))
        descriptiveStatistic = DescriptiveStatistic(json_data.get("descriptiveStatistic")) if json_data.get(
            "descriptiveStatistic") is not None else None
        userNotes = json_data.get("userNotes")

        return cls(bodyWeight=bodyWeight, timeFrame=timeFrame,
                   descriptiveStatistic=descriptiveStatistic,
                   userNotes=userNotes)
