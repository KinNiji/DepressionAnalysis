#! /usr/bin/env python
# -*- coding: UTF-8 -*-
from ..unitvalue import LengthUnitValue

from ...Measure import Measure
from ...SchemaId import SchemaId
from ...basictypes import TimeFrame
from ...enums import DescriptiveStatistic, Namespace


class BodyHeight(Measure):
    """
    body height definition
    """

    def __init__(self, bodyHeight: LengthUnitValue,
                 timeFrame: TimeFrame = None, descriptiveStatistic: DescriptiveStatistic = None,
                 userNotes: str = None):
        """
        create body height bean
        :param body_height: body height
        :param time_frame: time frame
        :param descriptive_statistics: description statistics
        :param userNotes: user notes
        """
        super(BodyHeight, self).__init__(timeFrame, descriptiveStatistic, userNotes)

        self.__schemaId = SchemaId(Namespace.NAMESPACE_SPORTS, "BodyHeight")

        self.bodyHeight = bodyHeight
        self.timeFrame = timeFrame
        self.descriptiveStatistic = descriptiveStatistic
        self.userNotes = userNotes

    def getBodyHeight(self) -> LengthUnitValue:
        return self.bodyHeight

    def getSchemaId(self) -> SchemaId:
        return self.__schemaId

    @classmethod
    def from_json(cls, json_data: dict):
        bodyHeight = LengthUnitValue.from_json(json_data.get("bodyHeight"))
        timeFrame = TimeFrame(json_data.get("timeFrame"))
        descriptiveStatistic = DescriptiveStatistic(json_data.get("descriptiveStatistic")) if json_data.get(
            "descriptiveStatistic") is not None else None
        userNotes = json_data.get("userNotes")

        return cls(bodyHeight=bodyHeight, timeFrame=timeFrame,
                   descriptiveStatistic=descriptiveStatistic,
                   userNotes=userNotes)
