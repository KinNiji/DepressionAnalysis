#! /usr/bin/env python
# -*- coding: UTF-8 -*-

from ...Measure import Measure
from ...SchemaId import SchemaId
from ...basictypes import TimeFrame
from ...enums import Namespace,ReportedActivityIntensity
from ...standardfields.sports import Distance,CaloriesBurned

class PhysicalActivity(Measure):
    """
    distance definition
    """

    def __init__(self,activityName: str ,
                 timeFrame: TimeFrame = None,
                 distance: Distance = None,
                 caloriesBurned: CaloriesBurned = None,
                 reportedActivityIntensity: ReportedActivityIntensity = None,
                 metValue: int = None,
                 userNotes: str = None):
        """
        create distance bean
        :param distance: distance data point
        :param descriptive_statistics_denominator: descriptive statistics denominator
        :param time_frame: time frame
        :param descriptive_statistics: description statistics
        :param userNotes: user notes
        """
        super(PhysicalActivity, self).__init__(userNotes)

        self.__schemaId = SchemaId(Namespace.NAMESPACE_SPORTS, "PhysicalActivity")

        self.activityName = activityName
        self.timeFrame = timeFrame
        self.distance = distance
        self.caloriesBurned = caloriesBurned
        self.reportedActivityIntensity = reportedActivityIntensity
        self.metValue = metValue
        self.userNotes = userNotes

    def getSchemaId(self) -> SchemaId:
        return self.__schemaId

    @classmethod
    def from_json(cls, json_data: dict):
        activityName = json_data.get("activityName")
        timeFrame = TimeFrame(json_data.get("timeFrame")) if json_data.get(
            "timeFrame") is not None else None
        distance = Distance(json_data.get("distance")) if json_data.get(
            "distance") is not None else None
        caloriesBurned = CaloriesBurned(json_data.get("caloriesBurned")) if json_data.get(
            "caloriesBurned") is not None else None
        reportedActivityIntensity = ReportedActivityIntensity(json_data.get("reportedActivityIntensity"))if json_data.get(
            "reportedActivityIntensity") is not None else None
        metValue = json_data.get("metValue")if json_data.get(
            "metValue") is not None else None
        userNotes = json_data.get("userNotes")

        return cls(activityName=activityName,
                   timeFrame=timeFrame,
                   distance=distance,
                   caloriesBurned=caloriesBurned,
                   reportedActivityIntensity=reportedActivityIntensity,
                   metValue=metValue,
                   userNotes=userNotes)
