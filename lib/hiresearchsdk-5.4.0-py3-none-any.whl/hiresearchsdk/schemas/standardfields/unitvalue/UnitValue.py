#! /usr/bin/env python
# -*- coding: UTF-8 -*-
from ...basictypes import UnitValue

from ...Unit import Unit
class UnitValue(UnitValue):
    def __init__(self, value: int, unit: Unit = None):
        """
        create a unitvalue
        :param value: value
        :param unit: must be AngularVelocityUnit
        """
        super(UnitValue, self).__init__(value, unit)