#! /usr/bin/env python
# -*- coding: UTF-8 -*-

from ...basictypes import UnitValue
from ...units import AngularVelocityUnit


class AngularVelocityUnitValue(UnitValue):
    """
    angular velocity unitvalue definition
    """

    def __init__(self, value: float, unit: AngularVelocityUnit):
        """
        create a datapoint
        :param value: value
        :param unit: must be AngularVelocityUnit
        """
        if unit is None:
            unit = AngularVelocityUnit.RAD_MERCURY

        super(AngularVelocityUnitValue, self).__init__(value, unit)