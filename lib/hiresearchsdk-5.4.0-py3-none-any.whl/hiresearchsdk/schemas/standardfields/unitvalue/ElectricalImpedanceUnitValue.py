# -*- coding: UTF-8 -*-

from ...basictypes import UnitValue
from ...units import ElectricalImpedanceUnit


class ElectricalImpedanceUnitValue(UnitValue):
    """
    voltage unitvalue definition
    """

    def __init__(self, value: float, unit: ElectricalImpedanceUnit):
        """
        create a unitvalue
        :param value: value
        :param unit: must be AngularVelocityUnit
        """

        super(ElectricalImpedanceUnitValue, self).__init__(value, unit)