#! /usr/bin/env python
# -*- coding: UTF-8 -*-
from ...basictypes import UnitValue
from ...units import OxygenSaturationUnit
class OxygenSaturationUnitValue(UnitValue):
    def __init__(self, value: any, unit: OxygenSaturationUnit):
        """
                create a datapoint
                :param value: value
                :param unit: must be HeartRateUnit
                """
        if unit is None:
            unit = OxygenSaturationUnit.PER_CENT

        super(OxygenSaturationUnitValue, self).__init__(value, unit)

class OxygenSaturationUnitValueFactory(object):
    """
    datapoint factory
    """

    @staticmethod
    def newFloatUnitValue(value: float, unit: OxygenSaturationUnit = None) -> OxygenSaturationUnitValue:
        """
        create datapoint with a float value
        :param value: must be float
        :param unit: must be HeartRateUnit
        :return:
        """
        return OxygenSaturationUnitValue(value, unit)

    @staticmethod
    def newIntUnitValue(value: int, unit: OxygenSaturationUnit = None) -> OxygenSaturationUnitValue:
        """
        create datapoint with a int value
        :param value: must be int
        :param unit: must be HeartRateUnit
        :return:
        """
        return OxygenSaturationUnitValue(value, unit)