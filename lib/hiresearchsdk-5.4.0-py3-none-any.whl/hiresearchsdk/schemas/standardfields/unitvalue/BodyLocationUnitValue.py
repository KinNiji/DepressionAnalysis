#! /usr/bin/env python
# -*- coding: UTF-8 -*-
from ...basictypes import UnitValue
from ...enums import BodyLocation


class BodyLocationUnitValue(UnitValue):
    """
    blood pressure datapoint definition
    """

    def __init__(self, value: any, unit: BodyLocation = None):
        """
        create a datapoint
        :param value: must be float
        :param unit: must be BloodPressureUnit
        """
        super(BodyLocationUnitValue, self).__init__(value, unit)
class BodyLocationUnitValueFactory(object):
    """
    datapoint factory
    """
    @staticmethod
    def newStrUnitValue(value: str, unit: BodyLocation) -> BodyLocationUnitValue:
        """
        create datapoint with a float value
        :param value: must be float
        :param unit: must be DurationUnit
        :return:
        """
        return BodyLocationUnitValue(value, unit)
