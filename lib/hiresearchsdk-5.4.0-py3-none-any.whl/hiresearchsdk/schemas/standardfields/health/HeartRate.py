#! /usr/bin/env python
# -*- coding: UTF-8 -*-

from ..unitvalue import HeartRateUnitValue
from ...Measure import Measure
from ...SchemaId import SchemaId
from ...basictypes import TimeFrame
from ...enums import DescriptiveStatistic, Namespace, TemporalRelationshipToSleep, \
    TemporalRelationshipToPhysicalActivity


class HeartRate(Measure):
    """
    heartrate definition
    """

    def __init__(self, heartRate: HeartRateUnitValue,
                 relationshipToPhysicalActivity: TemporalRelationshipToPhysicalActivity = None,
                 relationshipToSleep: TemporalRelationshipToSleep = None,
                 timeFrame: TimeFrame = None,
                 descriptiveStatistic: DescriptiveStatistic = None,
                 userNotes: str = None):
        """
        create heartrate bean
        :param heart_rate: heartrate datapoint
        :param relationship_to_physical_activity:  relationship to physical activity
        :param relationship_to_sleep: relationship to sleep
        :param time_frame: time frame
        :param descriptive_statistics: description statistics
        :param userNotes: user notes
        """
        super(HeartRate, self).__init__(timeFrame,descriptiveStatistic, userNotes)

        self.__schemaId = SchemaId(Namespace.NAMESPACE_HEALTH, "HeartRate")

        self.heartRate = heartRate
        self.relationshipToPhysicalActivity = relationshipToPhysicalActivity
        self.relationshipToSleep = relationshipToSleep
        self.timeFrame = timeFrame
        self.descriptiveStatistic = descriptiveStatistic
        self.userNotes = userNotes

    def getHeartRate(self) -> HeartRateUnitValue:
        return self.heartRate

    def getRelationshipToPhysicalActivity(self) -> str:
        return self.relationshipToPhysicalActivity.value

    def getRelationshipToSleep(self) -> str:
        return self.relationshipToSleep.value

    def getSchemaId(self) -> SchemaId:
        return self.__schemaId

    @classmethod
    def from_json(cls, json_data: dict):
        heartrate = HeartRateUnitValue(json_data.get("heartRate"))
        print(heartrate)
        relationshipToPhysicalActivity = TemporalRelationshipToPhysicalActivity(
            json_data.get("relationshipToPhysicalActivity")) if json_data.get(
            "relationshipToPhysicalActivity") is not None else None
        relationshipToSleep = TemporalRelationshipToSleep(json_data.get("relationshipToSleep")) if json_data.get(
            "relationshipToSleep") is not None else None
        timeFrame = TimeFrame(json_data.get("timeFrame"))
        descriptiveStatistic = DescriptiveStatistic(json_data.get("descriptiveStatistic")) if json_data.get("descriptiveStatistic") is not None else None
        userNotes = json_data.get("userNotes")

        return cls(heartrate=heartrate, relationshipToPhysicalActivity=relationshipToPhysicalActivity,
                   relationshipToSleep=relationshipToSleep, timeFrame=timeFrame,
                   descriptiveStatistic=descriptiveStatistic,
                   userNotes=userNotes)
