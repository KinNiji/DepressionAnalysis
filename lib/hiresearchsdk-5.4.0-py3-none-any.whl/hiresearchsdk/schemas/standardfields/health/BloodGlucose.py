#! /usr/bin/env python
# -*- coding: UTF-8 -*-

from ..unitvalue import BloodGlucoseUnitValue
from ...Measure import Measure
from ...SchemaId import SchemaId
from ...basictypes import TimeFrame
from ...enums import BodyLocation, DescriptiveStatistic, Namespace,TemporalRelationshipToSleep,TemporalRelationshipToMeal,SpecimenSource


class BloodGlucose(Measure):
    """
    blood pressure definition
    """

    def __init__(self, bloodGlucose: BloodGlucoseUnitValue,
                 specimenSource: SpecimenSource = None,
                 timeFrame: TimeFrame = None,
                 descriptiveStatistic: DescriptiveStatistic = None,
                 relationshipToSleep: TemporalRelationshipToSleep = None,
                 relationshipToMeal: TemporalRelationshipToMeal = None,
                 userNotes: str = None):
        """
        create a blood pressure bean
        :param systolic_blood_pressure: systolic blood pressure datapoint
        :param diastolic_blood_pressure: diastolic blood pressure datapoint
        :param body_posture: body posture
        :param time_frame: time frame
        :param descriptive_statistics: description statistics
        :param userNotes: user notes
        """
        super(BloodGlucose, self).__init__(timeFrame, descriptiveStatistic, userNotes)

        self.__schemaId = SchemaId(Namespace.NAMESPACE_HEALTH, "BloodGlucose")

        self.bloodGlucose = bloodGlucose
        self.specimenSource = specimenSource
        self.timeFrame = timeFrame
        self.descriptiveStatistic = descriptiveStatistic
        self.relationshipToSleep = relationshipToSleep
        self.relationshipToMeal = relationshipToMeal
        self.userNotes = userNotes

    def getBloodGlucose(self) -> BloodGlucoseUnitValue:
        return self.bloodGlucose
    def getSpecimenSource(self) -> BloodGlucoseUnitValue:
        return self.specimenSource
    def getRelationshipToSleep(self) -> BloodGlucoseUnitValue:
        return self.relationshipToSleep
    def getRelationshipToMeal(self) -> BloodGlucoseUnitValue:
        return self.relationshipToMeal
    def getSchemaId(self) -> SchemaId:
        return self.__schemaId

    @classmethod
    def from_json(cls, json_data: dict):
        bloodGlucose = BloodGlucoseUnitValue.from_json(json_data.get("bloodGlucose"))
        specimenSource = SpecimenSource.from_json(json_data.get("specimenSource"))if json_data.get(
            "specimen_source") is not None else None
        relationshipToSleep = TemporalRelationshipToSleep(json_data.get("relationshipToSleep")) if json_data.get(
            "relationshipToSleep") is not None else None
        timeFrame = TimeFrame(json_data.get("timeFrame"))
        relationshipToMeal = TemporalRelationshipToMeal(json_data.get("relationshipToMeal")) if json_data.get(
            "relationshipToMeal") is not None else None
        descriptiveStatistic = DescriptiveStatistic(json_data.get("descriptiveStatistic")) if json_data.get(
            "DescriptiveStatistic") is not None else None
        userNotes = json_data.get("userNotes")

        return cls(bloodGlucose=bloodGlucose, specimenSource=specimenSource,
                   relationshipToSleep=relationshipToSleep, timeFrame=timeFrame, relationshipToMeal=relationshipToMeal,descriptiveStatistic = descriptiveStatistic,
                   userNotes=userNotes)
