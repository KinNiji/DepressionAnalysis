#! /usr/bin/env python
# -*- coding: UTF-8 -*-

from ..unitvalue import BloodPressureUnitValue
from ...Measure import Measure
from ...SchemaId import SchemaId
from ...basictypes import TimeFrame
from ...enums import BodyLocation, DescriptiveStatistic, Namespace


class BloodPressure(Measure):
    """
    blood pressure definition
    """

    def __init__(self, systolicBloodPressure: BloodPressureUnitValue,
                 diastolicBloodPressure: BloodPressureUnitValue,
                 bodyPosture: BodyLocation = None,
                 timeFrame: TimeFrame = None,
                 descriptiveStatistic: DescriptiveStatistic = None,
                 userNotes: str = None):
        """
        create a blood pressure bean
        :param systolic_blood_pressure: systolic blood pressure datapoint
        :param diastolic_blood_pressure: diastolic blood pressure datapoint
        :param body_posture: body posture
        :param time_frame: time frame
        :param descriptive_statistics: description statistics
        :param userNotes: user notes
        """
        super(BloodPressure, self).__init__(timeFrame, descriptiveStatistic, userNotes)

        self.__schemaId = SchemaId(Namespace.NAMESPACE_HEALTH, "BloodPressure")

        self.systolicBloodPressure = systolicBloodPressure
        self.diastolicBloodPressure = diastolicBloodPressure
        self.bodyPosture = bodyPosture
        self.timeFrame = timeFrame
        self.descriptiveStatistic = descriptiveStatistic
        self.userNotes = userNotes

    def getSystolicBloodPressure(self) -> BloodPressureUnitValue:
        return self.systolicBloodPressure

    def getDiastolicBloodPressure(self) -> BloodPressureUnitValue:
        return self.diastolicBloodPressure

    def getBodyPosture(self) -> str:
        return self.bodyPosture.value

    def getSchemaId(self) -> SchemaId:
        return self.__schemaId

    @classmethod
    def from_json(cls, json_data: dict):
        systolicBloodPressure = BloodPressureUnitValue.from_json(json_data.get("systolicBloodPressure"))
        diastolicBloodPressure = BloodPressureUnitValue.from_json(json_data.get("diastolicBloodPressure"))
        bodyPosture = BodyLocation(json_data.get("bodyPosture")) if json_data.get(
            "bodyPosture") is not None else None
        timeFrame = TimeFrame(json_data.get("timeFrame"))
        descriptiveStatistic = DescriptiveStatistic(json_data.get("descriptiveStatistic")) if json_data.get(
            "descriptiveStatistic") is not None else None
        userNotes = json_data.get("userNotes")

        return cls(systolicBloodPressure=systolicBloodPressure, diastolicBloodPressure=diastolicBloodPressure,
                   bodyPosture=bodyPosture, timeFrame=timeFrame, descriptiveStatistic=descriptiveStatistic,
                   userNotes=userNotes)
