#! /usr/bin/env python
# -*- coding: UTF-8 -*-

from ..unitvalue import TemperatureUnitValue
from ...Measure import Measure
from ...SchemaId import SchemaId
from ...basictypes import TimeFrame
from ...enums import DescriptiveStatistic, Namespace


class AmbientTemperature(Measure):
    """
    blood pressure definition
    """

    def __init__(self, ambientTemperature: TemperatureUnitValue,
                 timeFrame: TimeFrame = None,
                 descriptiveStatistic: DescriptiveStatistic = None,
                 userNotes: str = None):
        """
        create a blood pressure bean
        :param systolic_blood_pressure: systolic blood pressure datapoint
        :param diastolic_blood_pressure: diastolic blood pressure datapoint
        :param body_posture: body posture
        :param time_frame: time frame
        :param descriptive_statistics: description statistics
        :param userNotes: user notes
        """
        super(AmbientTemperature, self).__init__(timeFrame, descriptiveStatistic, userNotes)

        self.__schemaId = SchemaId(Namespace.NAMESPACE_HEALTH, "ambientTemperature")
        self.ambientTemperature = ambientTemperature
        self.timeFrame = timeFrame
        self.descriptiveStatistic = descriptiveStatistic
        self.userNotes = userNotes

    def getAmbientTemperature(self) -> TemperatureUnitValue:
        return self.WristCircumference

    def getSchemaId(self) -> SchemaId:
        return self.__schemaId

    @classmethod
    def from_json(cls, json_data: dict):
        ambientTemperature = TemperatureUnitValue.from_json(json_data.get("ambientTemperature"))
        timeFrame = TimeFrame(json_data.get("timeFrame"))
        descriptiveStatistic = DescriptiveStatistic(json_data.get("descriptiveStatistic")) if json_data.get(
            "DescriptiveStatistic") is not None else None
        userNotes = json_data.get("userNotes")

        return cls(ambientTemperature=ambientTemperature,
                  timeFrame=timeFrame, descriptiveStatistic = descriptiveStatistic,
                   userNotes=userNotes)
