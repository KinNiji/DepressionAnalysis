#! /usr/bin/env python
# -*- coding: UTF-8 -*-

from ..unitvalue import RRIUnitValue
from ...Measure import Measure
from ...SchemaId import SchemaId
from ...basictypes import TimeFrame
from ...enums import DescriptiveStatistic, Namespace, TemporalRelationshipToPhysicalActivity


class RRI(Measure):
    """
    RRI definition
    """

    def __init__(self, rri: RRIUnitValue,sqi: int = None,
                 relationshipToPhysicalActivity: TemporalRelationshipToPhysicalActivity = None,
                 timeFrame: TimeFrame = None, descriptiveStatistic: DescriptiveStatistic = None,
                 userNotes: str = None):
        """
        create rri bean
        :param rri: heartrate rri
        :param relationship_to_physical_activity:  relationship to physical activity
        :param time_frame: time frame
        :param descriptive_statistics: description statistics
        :param userNotes: user notes
        """
        super(RRI, self).__init__(timeFrame, descriptiveStatistic, userNotes)

        self.__schemaId = SchemaId(Namespace.NAMESPACE_HEALTH, "RRI")

        self.rri = rri
        self.sqi = sqi
        self.relationshipToPhysicalActivity = relationshipToPhysicalActivity
        self.timeFrame = timeFrame
        self.descriptiveStatistic = descriptiveStatistic
        self.userNotes = userNotes

    def getRRI(self) -> RRIUnitValue:
        return self.rri
    def getSqi(self) -> int:
        return self.sqi
    def getRelationshipToPhysicalActivity(self) -> str:
        return self.relationshipToPhysicalActivity.value

    def getSchemaId(self) -> SchemaId:
        return self.__schemaId

    @classmethod
    def from_json(cls, json_data: dict):
        rri = RRIUnitValue.from_json(json_data.get("rri"))
        sqi = json_data.get("sqi")if json_data.get(
            "sqi") is not None else None
        relationshipToPhysicalActivity = TemporalRelationshipToPhysicalActivity(
            json_data.get("relationshipToPhysicalActivity")) if json_data.get(
            "relationshipToPhysicalActivity") is not None else None
        timeFrame = TimeFrame(json_data.get("timeFrame"))
        descriptiveStatistic = DescriptiveStatistic(json_data.get("descriptiveStatistic")) if json_data.get(
            "descriptiveStatistic") is not None else None
        userNotes = json_data.get("userNotes")if json_data.get(
            "descriptiveStatistic") is not None else None

        return cls(rri=rri, sqi = sqi,relationshipToPhysicalActivity=relationshipToPhysicalActivity, timeFrame=timeFrame,
                   descriptiveStatistic=descriptiveStatistic,
                   userNotes=userNotes)
