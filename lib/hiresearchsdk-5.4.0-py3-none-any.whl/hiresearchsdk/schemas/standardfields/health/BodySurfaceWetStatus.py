#! /usr/bin/env python
# -*- coding: UTF-8 -*-

from ..unitvalue import BodyLocationUnitValue
from ...Measure import Measure
from ...SchemaId import SchemaId
from ...basictypes import TimeFrame
from ...enums import  Namespace,WetStatus,BodyLocation


class BodySurfaceWetStatus(Measure):
    """
    blood pressure definition
    """

    def __init__(self, wetStatus: WetStatus,
                 bodyLocation: BodyLocation = None,
                 userNotes: str = None):
        """
        create a blood pressure bean
        :param systolic_blood_pressure: systolic blood pressure datapoint
        :param diastolic_blood_pressure: diastolic blood pressure datapoint
        :param body_posture: body posture
        :param time_frame: time frame
        :param descriptive_statistics: description statistics
        :param userNotes: user notes
        """
        self.__schemaId = SchemaId(Namespace.NAMESPACE_HEALTH, "BodySurfaceWetStatus")

        self.bodyLocation = bodyLocation
        self.wetStatus = wetStatus
        self.userNotes = userNotes
    def getWetStatus(self) -> WetStatus:
        return self.wetStatus
    def getSchemaId(self) -> SchemaId:
        return self.__schemaId

    @classmethod
    def from_json(cls, json_data: dict):
        wetStatus = WetStatus(json_data.get("wetStatus"))
        bodyLocation = BodyLocation(json_data.get("bodyLocation"))if json_data.get(
            "bodyLocation") is not None else None
        userNotes = json_data.get("userNotes")

        return cls(bodyLocation=bodyLocation, wetStatus=wetStatus,
                   userNotes=userNotes)
