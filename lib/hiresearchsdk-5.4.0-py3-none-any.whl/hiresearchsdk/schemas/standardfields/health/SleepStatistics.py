#! /usr/bin/env python
# -*- coding: UTF-8 -*-


from ..unitvalue import DurationUnitValue
from ...Measure import Measure
from ...SchemaId import SchemaId
from ...basictypes import TimeFrame
from ...enums import DescriptiveStatistic, Namespace


class SleepStatistics(Measure):
    """
    sleep statistics definition
    """

    def __init__(self, fallAsleepTime: TimeFrame,
                 wakeupTime: TimeFrame,
                 goBedTime: TimeFrame = None,
                 latencyTime: DurationUnitValue = None,
                 lightSleepTime: DurationUnitValue = None,
                 deepSleepTime: DurationUnitValue = None,
                 dreamTime: DurationUnitValue = None,
                 awakeTime: DurationUnitValue = None,
                 allSleepTime: DurationUnitValue = None,
                 daySleepTime: DurationUnitValue = None,
                 numberOfAwakenings: int = 0,
                 userNotes: str = None):
        """
        create sleep statistics bean
        :param fallasleep_time: time when falling asleep
        :param wakeup_time: time when waking up
        :param gobed_time: time whne going to bed
        :param latency_time: latency time duration before asleep
        :param light_sleep_time: light sleep duration
        :param deep_sleep_time: deep sleep duration
        :param dream_time: dream duration
        :param awake_time: awake duration
        :param all_sleep_time: total sleep time duration
        :param day_sleep_time: day sleep duraion
        :param number_of_awakenings: times of awakenings
        :param time_frame: time frame
        :param descriptive_statistics: description statistics
        :param userNotes: user notes
        """
        self.__schemaId = SchemaId(Namespace.NAMESPACE_SLEEP, "SleepStatistics")

        self.fallAsleepTime = fallAsleepTime
        self.wakeupTime = wakeupTime
        self.goBedTime = goBedTime
        self.latencyTime = latencyTime
        self.lightSleepTime = lightSleepTime
        self.deepSleepTime = deepSleepTime
        self.dreamTime = dreamTime
        self.awakeTime = awakeTime
        self.allSleepTime = allSleepTime
        self.daySleepTime = daySleepTime
        self.numberOfAwakenings = numberOfAwakenings
        self.userNotes = userNotes

    def getFallAsleepTime(self) -> TimeFrame:
        return self.fallAsleepTime

    def getWakeupTime(self) -> TimeFrame:
        return self.wakeupTime

    def getGoBedTime(self) -> TimeFrame:
        return self.goBedTime

    def getLatencyTime(self) -> DurationUnitValue:
        return self.latencyTime

    def getLightSleepTime(self) -> DurationUnitValue:
        return self.lightSleepTime

    def getDeepSleepTime(self) -> DurationUnitValue:
        return self.deepSleepTime

    def getDreamTime(self) -> DurationUnitValue:
        return self.dreamTime

    def getAwakeTime(self) -> DurationUnitValue:
        return self.awakeTime

    def getAllSleepTime(self) -> DurationUnitValue:
        return self.allSleepTime

    def getDaySleepTime(self) -> DurationUnitValue:
        return self.daySleepTime

    def getNumberOfAwakenings(self) -> int:
        return self.numberOfAwakenings

    def getSchemaId(self):
        return self.__schemaId

    @classmethod
    def from_json(cls, json_data: dict):
        fallAsleepTime = TimeFrame(json_data.get("fallAsleepTime"))
        wakeupTime = TimeFrame(json_data.get("wakeupTime"))
        goBedTime = TimeFrame(json_data.get("goBedTime"))if json_data.get(
            "goBedTime") is not None else None
        latencyTime = DurationUnitValue(json_data.get("latencyTime"))if json_data.get(
            "latencyTime") is not None else None
        lightSleepTime = DurationUnitValue(json_data.get("lightSleepTime"))if json_data.get(
            "lightSleepTime") is not None else None
        deepSleepTime = DurationUnitValue(json_data.get("deepSleepTime"))if json_data.get(
            "deepSleepTime") is not None else None
        dreamTime = DurationUnitValue(json_data.get("dreamTime"))if json_data.get(
            "dreamTime") is not None else None
        awakeTime = DurationUnitValue(json_data.get("awakeTime"))if json_data.get(
            "awakeTime") is not None else None
        allSleepTime = DurationUnitValue(json_data.get("allSleepTime"))if json_data.get(
            "allSleepTime") is not None else None
        daySleepTime = DurationUnitValue(json_data.get("daySleepTime"))if json_data.get(
            "daySleepTime") is not None else None
        numberOfAwakenings = json_data.get("numberOfAwakenings")if json_data.get(
            "numberOfAwakenings") is not None else None
        userNotes = json_data.get("userNotes")if json_data.get(
            "userNotes") is not None else None

        return cls(fallAsleepTime=fallAsleepTime,
                   wakeupTime=wakeupTime,
                   goBedTime=goBedTime,
                   latencyTime=latencyTime,
                   lightSleepTime=lightSleepTime,
                   deepSleepTime=deepSleepTime,
                   dreamTime=dreamTime,
                   awakeTime=awakeTime,
                   allSleepTime=allSleepTime,
                   daySleepTime=daySleepTime,
                   numberOfAwakenings=numberOfAwakenings,
                   userNotes=userNotes)
