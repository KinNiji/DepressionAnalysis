#! /usr/bin/env python
# -*- coding: UTF-8 -*-

from ..unitvalue import LengthUnitValue
from ...Measure import Measure
from ...SchemaId import SchemaId
from ...basictypes import TimeFrame
from ...enums import DescriptiveStatistic, Namespace


class WristCircumference(Measure):
    """
    blood pressure definition
    """

    def __init__(self, wristCircumference: LengthUnitValue,
                 timeFrame: TimeFrame = None,
                 descriptiveStatistic: DescriptiveStatistic = None,
                 userNotes: str = None):
        """
        create a blood pressure bean
        :param systolic_blood_pressure: systolic blood pressure datapoint
        :param diastolic_blood_pressure: diastolic blood pressure datapoint
        :param body_posture: body posture
        :param time_frame: time frame
        :param descriptive_statistics: description statistics
        :param userNotes: user notes
        """
        super(WristCircumference, self).__init__(timeFrame, descriptiveStatistic, userNotes)

        self.__schemaId = SchemaId(Namespace.NAMESPACE_HEALTH, "wristCircumference")
        self.wristCircumference = wristCircumference
        self.timeFrame = timeFrame
        self.descriptiveStatistic = descriptiveStatistic
        self.userNotes = userNotes

    def getWristCircumference(self) -> LengthUnitValue:
        return self.WristCircumference

    def getSchemaId(self) -> SchemaId:
        return self.__schemaId

    @classmethod
    def from_json(cls, json_data: dict):
        wristCircumference = LengthUnitValue.from_json(json_data.get("wristCircumference"))
        timeFrame = TimeFrame(json_data.get("timeFrame"))
        descriptiveStatistic = DescriptiveStatistic(json_data.get("descriptiveStatistic")) if json_data.get(
            "DescriptiveStatistic") is not None else None
        userNotes = json_data.get("userNotes")

        return cls(wristCircumference=wristCircumference,
                  timeFrame=timeFrame, descriptiveStatistic = descriptiveStatistic,
                   userNotes=userNotes)
