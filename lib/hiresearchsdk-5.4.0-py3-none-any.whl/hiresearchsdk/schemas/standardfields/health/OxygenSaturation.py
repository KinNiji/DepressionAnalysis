#! /usr/bin/env python
# -*- coding: UTF-8 -*-

from ..unitvalue import OxygenSaturationUnitValue
from ...Measure import Measure
from ...SchemaId import SchemaId
from ...basictypes import TimeFrame
from ...enums import DescriptiveStatistic, Namespace, TemporalRelationshipToMeal, TemporalRelationshipToPhysicalActivity,TemporalRelationshipToSleep


class OxygenSaturation(Measure):
    """
    OxygenSaturation definition
    """

    def __init__(self, oxygenSaturation: OxygenSaturationUnitValue,
                 timeFrame: TimeFrame = None):
        """
        create OxygenSaturation bean
        :param OxygenSaturation: heartrate datapoint
        :param relationship_to_physical_activity:  relationship to physical activity
        :param relationship_to_sleep: relationship to sleep
        :param time_frame: time frame
        :param descriptive_statistics: description statistics
        :param userNotes: user notes
        """
        super(OxygenSaturation, self).__init__(timeFrame)
        self.__schemaId = SchemaId(Namespace.NAMESPACE_HEALTH, "OxygenSaturation")
        self.timeFrame = timeFrame
        self.oxygenSaturation = oxygenSaturation
    def getOxygenSaturation(self) -> OxygenSaturationUnitValue:
        return self.oxygenSaturation

    def getSchemaId(self) -> SchemaId:
        return self.__schemaId

    @classmethod
    def from_json(cls, json_data: dict):
        oxygenSaturation = OxygenSaturationUnitValue.from_json(json_data.get("oxygenSaturation"))
        timeFrame = TimeFrame(json_data.get("timeFrame"))


        return cls(oxygenSaturation=oxygenSaturation,
                   timeFrame=timeFrame
                   )
