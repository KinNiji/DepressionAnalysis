#! /usr/bin/env python
# -*- coding: UTF-8 -*-

from ..unitvalue import AngularVelocityUnitValue
from ...Measure import Measure
from ...SchemaId import SchemaId
from ...basictypes import TimeFrame
from ...enums import DescriptiveStatistic, Namespace, BodyLocation


class Orientation(Measure):
    """
    blood pressure definition
    """

    def __init__(self, angularVelocity_x: AngularVelocityUnitValue,
                 angularVelocity_y: AngularVelocityUnitValue,
                 angularVelocity_z: AngularVelocityUnitValue,
                 timeFrame: TimeFrame = None,
                 sensorBodyLocation: BodyLocation = None,
                 descriptiveStatistic: DescriptiveStatistic = None
                 ):
        """
        create a blood pressure bean
        :param systolic_blood_pressure: systolic blood pressure datapoint
        :param diastolic_blood_pressure: diastolic blood pressure datapoint
        :param body_posture: body posture
        :param time_frame: time frame
        :param descriptive_statistics: description statistics
        :param userNotes: user notes
        """
        super(Orientation, self).__init__(timeFrame,descriptiveStatistic)

        self.__schemaId = SchemaId(Namespace.NAMESPACE_SENSOR, "Acceleration")

        self.angularVelocity_x = angularVelocity_x
        self.angularVelocity_y = angularVelocity_y
        self.angularVelocity_z = angularVelocity_z
        self.timeFrame = timeFrame
        self.sensorBodyLocation = sensorBodyLocation
        self.descriptiveStatistic = descriptiveStatistic

    def getAngularVelocity_x(self) -> AngularVelocityUnitValue:
        return self.angularVelocity_x

    def getAngularVelocity_y(self) -> AngularVelocityUnitValue:
        return self.angularVelocity_y

    def getAngularVelocity_z(self) -> AngularVelocityUnitValue:
        return self.angularVelocity_z

    def getSchemaId(self) -> SchemaId:
        return self.__schemaId

    @classmethod
    def from_json(cls, json_data: dict):
        angularVelocity_x = AngularVelocityUnitValue.from_json(json_data.get("angularVelocity_x"))
        angularVelocity_y = AngularVelocityUnitValue.from_json(json_data.get("angularVelocity_y"))
        angularVelocity_z = AngularVelocityUnitValue.from_json(json_data.get("angularVelocity_z"))
        timeFrame = TimeFrame(json_data.get("timeFrame"))
        sensorBodyLocation = BodyLocation(json_data.get("sensorBodyLocation")) if json_data.get(
            "sensorBodyLocation") is not None else None
        descriptiveStatistic = DescriptiveStatistic(json_data.get("descriptiveStatistic")) if json_data.get(
            "DescriptiveStatistic") is not None else None

        return cls(angularVelocity_x=angularVelocity_x, angularVelocity_y=angularVelocity_y,
                   angularVelocity_z=angularVelocity_z, timeFrame=timeFrame, sensorBodyLocation=sensorBodyLocation,
                   descriptiveStatistic=descriptiveStatistic
                   )
