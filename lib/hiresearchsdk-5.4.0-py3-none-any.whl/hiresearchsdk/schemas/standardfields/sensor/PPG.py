#! /usr/bin/env python
# -*- coding: UTF-8 -*-

from ..unitvalue import AngularVelocityUnitValue
from ...Measure import Measure
from ...SchemaId import SchemaId
from ...basictypes import TimeFrame
from ...enums import DescriptiveStatistic, Namespace, BodyLocation, SkinColor, SkinToneUniformity, \
    HairThickness
from ...standardfields.health import WristCircumference,AmbientTemperature


class PPG(Measure):
    """
    blood pressure definition
    """

    def __init__(self, measurementWristCircumference: WristCircumference,
                 skinColor: SkinColor ,
                 skinToneUniformity: SkinToneUniformity ,
                 measurementAmbientTemperature: AmbientTemperature ,
                 hairThickness: HairThickness = None,
                 greenLight:list = None,
                 redLight:list = None,
                 infraredLight :list = None,
                 ambientLight:list = None,
                 timeFrame: TimeFrame = None,
                 sensorBodyLocation: BodyLocation = None,
                 userNotes: str = None
                 ):
        """
        create a blood pressure bean
        :param systolic_blood_pressure: systolic blood pressure datapoint
        :param diastolic_blood_pressure: diastolic blood pressure datapoint
        :param body_posture: body posture
        :param time_frame: time frame
        :param descriptive_statistics: description statistics
        :param userNotes: user notes
        """
        super(PPG, self).__init__(userNotes)
        self.__schemaId = SchemaId(Namespace.NAMESPACE_SENSOR, "PPG")

        self.measurementWristCircumference = measurementWristCircumference
        self.skinColor = skinColor
        self.skinToneUniformity = skinToneUniformity
        self.measurementAmbientTemperature = measurementAmbientTemperature
        self.hairThickness = hairThickness
        self.greenLight = greenLight
        self.infraredLight = infraredLight
        self.redLight = redLight
        self.ambientLight = ambientLight
        self.timeFrame = timeFrame
        self.sensorBodyLocation = sensorBodyLocation
        self.userNotes = userNotes

    def getSchemaId(self) -> SchemaId:
        return self.__schemaId

    @classmethod
    def from_json(cls, json_data: dict):
        measurementWristCircumference = WristCircumference(json_data.get("measurementWristCircumference"))
        skinColor = SkinColor(json_data.get("skinColor"))if json_data.get(
            "skinColor") is not None else None
        skinToneUniformity = SkinToneUniformity(json_data.get("skinToneUniformity"))if json_data.get(
            "skinToneUniformity") is not None else None
        measurementAmbientTemperature = AmbientTemperature(json_data.get("measurementAmbientTemperature"))if json_data.get(
            "measurementAmbientTemperature") is not None else None
        hairThickness = HairThickness(json_data.get("hairThickness")) if json_data.get(
            "hairThickness") is not None else None
        greenLight = json_data.get("greenLight") if json_data.get(
            "greenLight") is not None else None
        infraredLight = json_data.get("infraredLight") if json_data.get(
            "infraredLight") is not None else None
        redLight = json_data.get("redLight") if json_data.get(
            "redLight") is not None else None
        ambientLight = json_data.get("ambientLight") if json_data.get(
            "ambientLight") is not None else None
        timeFrame = TimeFrame(json_data.get("timeFrame"))
        sensorBodyLocation = BodyLocation(json_data.get("sensorBodyLocation")) if json_data.get(
            "sensorBodyLocation") is not None else None
        userNotes = json_data.get("userNotes")

        return cls(measurementWristCircumference=measurementWristCircumference, skinColor=skinColor,
                   skinToneUniformity=skinToneUniformity, measurementAmbientTemperature=measurementAmbientTemperature, hairThickness=hairThickness,
                   greenLight=greenLight,infraredLight=infraredLight,redLight=redLight,ambientLight=ambientLight,
                   timeFrame=timeFrame, sensorBodyLocation=sensorBodyLocation, userNotes=userNotes
                   )
