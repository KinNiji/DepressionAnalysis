#! /usr/bin/env python
# -*- coding: UTF-8 -*-

from ..unitvalue import AngularVelocityUnitValue,AccelerationUnitValue
from ...Measure import Measure
from ...SchemaId import SchemaId
from ...basictypes import TimeFrame
from ...enums import DescriptiveStatistic, Namespace,BodyLocation


class Acceleration(Measure):
    """
    blood pressure definition
    """

    def __init__(self, acceleration_x  : AccelerationUnitValue,
                 acceleration_y  : AccelerationUnitValue,
                 acceleration_z : AccelerationUnitValue,
                 timeFrame: TimeFrame = None,
                 sensorBodyLocation: BodyLocation = None,
                 descriptiveStatistic: DescriptiveStatistic = None
             ):
        """
        create a blood pressure bean
        :param systolic_blood_pressure: systolic blood pressure datapoint
        :param diastolic_blood_pressure: diastolic blood pressure datapoint
        :param body_posture: body posture
        :param time_frame: time frame
        :param descriptive_statistics: description statistics
        :param userNotes: user notes
        """
        super(Acceleration, self).__init__(timeFrame,descriptiveStatistic)

        self.__schemaId = SchemaId(Namespace.NAMESPACE_SENSOR, "Acceleration")

        self.acceleration_x = acceleration_x
        self.acceleration_y = acceleration_y
        self.acceleration_z = acceleration_z
        self.timeFrame = timeFrame
        self.sensorBodyLocation = sensorBodyLocation
        self.descriptiveStatistic = descriptiveStatistic

    def getAccelerationVelocityUnitX(self) -> AccelerationUnitValue:
        return self.accelerationVelocityUnitX
    def getAccelerationVelocityUnitY(self) -> AccelerationUnitValue:
        return self.accelerationVelocityUnitY
    def getAccelerationVelocityUnitZ(self) -> AccelerationUnitValue:
        return self.accelerationVelocityUnitZ
    def getSensorBodyLocation(self) -> BodyLocation:
        return self.sensorBodyLocation
    def getSchemaId(self) -> SchemaId:
        return self.__schemaId

    @classmethod
    def from_json(cls, json_data: dict):
        acceleration_x = AccelerationUnitValue.from_json(json_data.get("acceleration_x"))
        acceleration_y = AccelerationUnitValue.from_json(json_data.get("acceleration_y"))
        acceleration_z = AccelerationUnitValue.from_json(json_data.get("acceleration_z"))
        timeFrame = TimeFrame(json_data.get("timeFrame"))
        sensorBodyLocation = BodyLocation(json_data.get("sensorBodyLocation")) if json_data.get(
            "sensorBodyLocation") is not None else None
        descriptiveStatistic = DescriptiveStatistic(json_data.get("descriptiveStatistic")) if json_data.get(
            "DescriptiveStatistic") is not None else None

        return cls(acceleration_x=acceleration_x,
                   acceleration_y=acceleration_y,
                   acceleration_z=acceleration_z,
                   timeFrame=timeFrame,
                   sensorBodyLocation=sensorBodyLocation,
                   descriptiveStatistic = descriptiveStatistic
                   )
