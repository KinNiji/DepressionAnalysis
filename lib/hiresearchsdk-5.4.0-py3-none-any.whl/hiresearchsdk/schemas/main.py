print('__file__={0:<35} | __name__={1:<20} | __package__={2:<20}'.format(__file__, __name__, str(__package__)))

from schemas.standardfields.unitvalue import OxygenSaturationUnitValueFactory, LengthUnitValueFactory,VoltageUnitValue, \
    AccelerationUnitValue, AngularVelocityUnitValue, BloodGlucoseUnitValue, TemperatureUnitValue, \
    OxygenSaturationUnitValue, BloodPressureUnitValue, BodyLocationUnitValue, HeartRateUnitValue,ElectricalImpedanceUnitValue,RRIUnitValue,LengthUnitValue,MassUnitValue,KcalUnitValue,StepUnitValue,UnitValue,DurationUnitValue
from schemas.standardfields.health import HeartRate, BloodGlucose, BodySurfaceWetStatus, \
    OxygenSaturation, WristCircumference, BloodPressure, AmbientTemperature,RRI,SleepStatistics
from schemas.units import BloodGlucoseUnit, AccelerationUnit, TemperatureUnit
from schemas.enums import BodyLocation, SkinColor, SkinToneUniformity,WetStatus,HairThickness,TemporalRelationshipToPhysicalActivity,TemporalRelationshipToSleep
from schemas.standardfields.sports import PhysicalActivity,BodyHeight,BodyWeight,CaloriesBurned,Distance,PhysicalActivity,StepCount
from schemas.standardfields.sensor import Acceleration, Orientation, ECG, PPG
from schemas.basictypes import TimeFrame
UnitValue(10,"KM")
measurementWristCircumference = WristCircumference(10)
skinColor = SkinColor("TYPE II - White,fair")
skinToneUniformity = SkinToneUniformity("even")
measurementAmbientTemperature = AmbientTemperature(11)
hairThickness = HairThickness("normal")
a = VoltageUnitValue(10,"V")
b = RRI(11)
c = RRI(12)
d = RRI(13)
e = ElectricalImpedanceUnitValue(10,"KΩ")
voltage = [a,b,c,d,e]
timeFrame = TimeFrame(10,10)
sensorBodyLocation = BodyLocation("left hip")
result = ECG(measurementWristCircumference,skinColor,skinToneUniformity,measurementAmbientTemperature,hairThickness,voltage,timeFrame,sensorBodyLocation,"ecg")
result.dumps()
print(result.dumps().encode("gbk"))

str = "Ω"
print(str)
result = OxygenSaturation(OxygenSaturationUnitValue(10,"C"),TimeFrame(10,10))
# result = HeartRate(HeartRateUnitValue(10,"m"),TemporalRelationshipToPhysicalActivity("swimming"),TemporalRelationshipToSleep("before dawn"),TimeFrame(10,10),"average","ecg")
print(result.dumps())

result = BodySurfaceWetStatus(WetStatus("dry"),BodyLocation("left ankle"),"ecg")
print(result.dumps())



rri = RRI(RRIUnitValue(10),11,TemporalRelationshipToPhysicalActivity("swimming"),TimeFrame(10,10),"average","RRI")
print(rri.dumps())

sleep = SleepStatistics(TimeFrame(1),TimeFrame(1),TimeFrame(1),DurationUnitValue(1,"ps"),DurationUnitValue(1,"ps"),DurationUnitValue(1,"ps"),DurationUnitValue(1,"ps"),DurationUnitValue(1,"ps"),DurationUnitValue(1,"ps"),DurationUnitValue(1,"ps"),1,"sleep",)
print(sleep.dumps())
# b = ECG
# b.from_json({"timeFrame": "1111", "userNotes": "assa", "measurementWristCircumference": {"wristCircumference": 10}, "skinColor": "TYPE II - White,fair", "skinToneUniformity": "even", "measurementAmbientTemperature": {"ambientTemperature": 11}, "list": [11, 12, 1]}
#             )
# print(b)
