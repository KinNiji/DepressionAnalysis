#! /usr/bin/env python
# -*- coding: UTF-8 -*-

from ..ISchemaSupport import ISchemaSupport
from ..SchemaId import SchemaId
from ..Unit import Unit
from ..enums import Namespace


class UnitValue(ISchemaSupport):
    """
    unitvalue definition
    """

    def __init__(self, value: any, unit: Unit = None):
        """
        create a datapoint
        :param value: value is a required field
        :param unit: unit is not a required field
        """
        self.value = value
        self.unit = unit

        self.__schemaId = SchemaId(Namespace.NAMESPACE_BASICTYPES, "unit_value")

    def getValue(self) -> any:
        return self.value

    def getUnit(self) -> Unit:
        return self.unit

    def getSchemaId(self):
        return self.__schemaId

    @classmethod
    def from_json(cls, json_data: dict):
        if json_data is None:
            return None

        return cls(value=json_data.get("value"), unit=json_data.get("unit"))
