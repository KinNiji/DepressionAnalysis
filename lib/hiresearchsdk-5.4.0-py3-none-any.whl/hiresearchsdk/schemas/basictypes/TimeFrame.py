#! /usr/bin/env python
# -*- coding: UTF-8 -*-

from ..ISchemaSupport import ISchemaSupport
from ..SchemaId import SchemaId
from ..enums import Namespace


class TimeFrame(ISchemaSupport):
    """
    timestamp definition
    """

    def __init__(self, start_time: int = None, end_time: int = None, timestamp: int = None):
        """
        create an timestamp. start_time、end_time should not be together with timestamp
        :param start_time: start_time
        :param end_time: end_time
        :param timestamp: timestamp
        """
        self.startTime = start_time
        self.endTime = end_time
        self.timestamp = timestamp

        self.__schemaId = SchemaId(Namespace.NAMESPACE_BASICTYPES, "time_frame")

    def getStartTime(self) -> int:
        return self.startTime

    def getEndTime(self) -> int:
        return self.endTime

    def getTimestamp(self) -> int:
        return self.timestamp

    def getSchemaId(self) -> SchemaId:
        return self.schemaId

    @classmethod
    def from_json(cls, json_data: dict):
        if json_data is None:
            return None

        return cls(start_time=json_data.get("startTime"), end_time=json_data.get("endTime"),
                   timestamp=json_data.get("timestamp"))
