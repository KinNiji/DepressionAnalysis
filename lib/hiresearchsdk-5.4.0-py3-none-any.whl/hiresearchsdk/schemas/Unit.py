#! /usr/bin/env python
# -*- coding: UTF-8 -*-

from .ISchemaSupport import ISchemaSupport


class Unit(ISchemaSupport):
    """
    unit interface: all units must implements it
    """
    pass
