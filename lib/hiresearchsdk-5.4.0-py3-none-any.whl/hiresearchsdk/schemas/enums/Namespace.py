from enum import Enum


class Namespace(Enum):
    """
    namespace enum definition
    """
    NAMESPACE_HEALTH = "standard_healthdata"
    NAMESPACE_SPORTS = "standard_sportsdata"
    NAMESPACE_ENUMS = "enumeration"
    NAMESPACE_BASICTYPES = "standard_basictypes"
    NAMESPACE_SENSOR = "standard_sensor"
    NAMESPACE_SLEEP = "standard_sleepdata"
    def __init__(self, value):
        pass
