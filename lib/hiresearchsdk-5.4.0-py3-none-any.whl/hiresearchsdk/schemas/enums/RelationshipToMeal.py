#! /usr/bin/env python
# -*- coding: UTF-8 -*-

from enum import Enum

from .Namespace import Namespace
from ..SchemaId import SchemaId


class RelationshipToMeal(Enum):
    """
    relationship to meal enumeration definition
    """
    FASTING = "fasting"
    NOT_FASTING = "not fasting"
    BEFORE_MEAL = "before meal"
    BEFORE_BREAKFAST = "before breakfast"
    AFTER_BREAKFAST = "after breakfast"
    BEFORE_LUNCH = "before lunch"
    AFTER_LUNCH = "after lunch"
    BEFORE_DINNER = "before dinner"
    AFTER_DINENR = "after dinner"
    TWO_HOURS_POSTPRANDIAL = "2 hours postprandial"

    def __init__(self, value):
        self.__schemaId = SchemaId(Namespace.NAMESPACE_ENUMS, "temporal_relationship_to_meal")

    def getSchemaValue(self):
        return self.value

    def getSchemaId(self) -> SchemaId:
        return self.__schemaId
