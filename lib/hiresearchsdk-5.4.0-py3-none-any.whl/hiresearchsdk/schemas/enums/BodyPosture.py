#! /usr/bin/env python
# -*- coding: UTF-8 -*-

from enum import Enum


from .Namespace import Namespace
from ..SchemaId import SchemaId

class BodyPosture(Enum):
    """
    length unit enumeration definition
    """
    SITTING = "sitting"
    LYING_DOWN = "lying down"
    STANDING = "standing"
    SEMI_RECUMBENT = "semi recumbent"


    def __init__(self, value):
        self.__schemaId = SchemaId(Namespace.NAMESPACE_ENUMS, "BodyPosture")

    def getSchemaId(self) -> SchemaId:
        return self.__schemaId
    def getSchemaValue(self):
        return self.value
