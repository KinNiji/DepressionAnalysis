#! /usr/bin/env python
# -*- coding: UTF-8 -*-

from enum import Enum

from .Namespace import Namespace
from ..SchemaId import SchemaId


class WetStatus(Enum):
    """
    relationship to specimen source enumeration definition
    """
    DRY = "dry"
    SWEAT = "sweat"
    AFTER_WASHING = "after washing"
    AFTER_BATHING = "after bathing"


    def __init__(self, value):
        self.__schemaId = SchemaId(Namespace.NAMESPACE_ENUMS, "WetStatus")

    def getSchemaValue(self):
        return self.value

    def getSchemaId(self) -> SchemaId:
        return self.__schemaId
