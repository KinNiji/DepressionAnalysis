#! /usr/bin/env python
# -*- coding: UTF-8 -*-

from enum import Enum

from .Namespace import Namespace
from ..SchemaId import SchemaId


class DescriptiveStatisticDenominator(Enum):
    """
    descriptive statistics denominator enumeration definition
    """
    DAY = "d"
    WEEK = "wk"
    MONTH = "mo"
    EPISODE = "episode"
    MEAL = "meal"
    SESSION = "session"

    def __init__(self, value):
        self.__schemaId = SchemaId(Namespace.NAMESPACE_ENUMS, "DescriptiveStatisticDenominator")

    def getSchemaValue(self):
        return self.value

    def getSchemaId(self) -> SchemaId:
        return self.__schemaId
