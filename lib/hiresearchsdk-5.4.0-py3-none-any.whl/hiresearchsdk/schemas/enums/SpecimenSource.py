#! /usr/bin/env python
# -*- coding: UTF-8 -*-

from enum import Enum

from .Namespace import Namespace
from ..SchemaId import SchemaId


class SpecimenSource(Enum):
    """
    relationship to specimen source enumeration definition
    """
    BREATH = "breath"
    CAPILLARY_BLOOD = "capillary blood"
    INTERSTITIAL_FLUID = "interstitial fluid"
    SALIVA = "saliva"
    SWEAT = "sweat"
    TEARS = "tears"
    URINE = "urine"
    WHOLE_BLOOD = "whole blood"
    PLASMA = "plasma"
    SERUM = "serum"

    def __init__(self, value):
        self.__schemaId = SchemaId(Namespace.NAMESPACE_ENUMS, "SpecimenSource")

    def getSchemaValue(self):
        return self.value

    def getSchemaId(self) -> SchemaId:
        return self.__schemaId
