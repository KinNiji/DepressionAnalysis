#! /usr/bin/env python
# -*- coding: UTF-8 -*-

from enum import Enum

from .Namespace import Namespace
from ..SchemaId import SchemaId


class Race(Enum):
    """
    position during measurement enumeration definition
    """
    ASIAN = "Asian"
    BLACK_AFRICAN_OR_AFRICAN_AMERICAN = "Black, African, or African American"
    WHITE = "American Indian or Alaska Native"
    NATIVE_HAWAIIAN_OR_OTHER_PACIFIC_ISLANDER = "Native Hawaiian or other Pacific islander"
    OTHER_RACE = "Other Race"
    def __init__(self, value):
        self.__schemaId = SchemaId(Namespace.NAMESPACE_ENUMS, "Race")

    def getSchemaValue(self):
        return self.value

    def getSchemaId(self) -> SchemaId:
        return self.__schemaId
