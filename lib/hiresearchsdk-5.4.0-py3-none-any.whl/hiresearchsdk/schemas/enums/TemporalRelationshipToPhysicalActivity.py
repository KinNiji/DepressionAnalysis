#! /usr/bin/env python
# -*- coding: UTF-8 -*-

from enum import Enum

from .Namespace import Namespace
from ..SchemaId import SchemaId


class TemporalRelationshipToPhysicalActivity(Enum):
    """
    relationship to physical activity enumeration definition
    """
    AT_REST = "at rest"
    ACTIVE = "active"
    BEFORE_EXERCISE = "before excercise"
    DURING_EXERCISE = "during excercise"
    AFTER_EXCERCISE = "after excercise"
    WALKING = "walking"
    RUNNING = "running"
    CLIMBING = "climbing"
    RIDING = "riding"
    STANDING = "standing"
    LIGHT_SLEEP = "light sleep"
    DEEP_SLEEP = "deep sleep"
    AWAKE = "awake"
    SWIMMING = "swimming"

    def __init__(self, value):
        self.__schemaId = SchemaId(Namespace.NAMESPACE_ENUMS, "TemporalRelationshipToPhysicalActivity")

    def getSchemaValue(self):
        return self.value

    def getSchemaId(self):
        return self.__schemaId
