#! /usr/bin/env python
# -*- coding: UTF-8 -*-

from enum import Enum

from .Namespace import Namespace
from ..SchemaId import SchemaId


class RelationshipToSleep(Enum):
    """
    relationship to sleep enumeration definition
    """
    BEFORE_SLEEP = "before sleep"
    DURING_SLEEP = "during sleep"
    ON_WAKING = "on waking"
    BEFORE_DAWN = "before dawn"

    def __init__(self, value):
        self.__schemaId = SchemaId(Namespace.NAMESPACE_ENUMS, "temporal_relationship_to_sleep")

    def getSchemaValue(self):
        return self.value

    def getSchemaId(self) -> SchemaId:
        return self.__schemaId
