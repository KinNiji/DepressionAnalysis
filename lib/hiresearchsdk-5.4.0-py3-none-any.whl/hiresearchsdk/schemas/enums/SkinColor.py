#! /usr/bin/env python
# -*- coding: UTF-8 -*-

from enum import Enum

from .Namespace import Namespace
from ..SchemaId import SchemaId


class SkinColor(Enum):
    """
    length unit enumeration definition
    """
    TYPE_1 = "TYPE I - Light, pale white"
    TYPE_2 = "TYPE II - White,fair"
    TYPE_3 = "TYPE III - Medium, white to olive"
    TYPE_4 = "TYPE IV - Olive, moderate brown"
    TYPE_5 = "TYPE V - Brown,dark brown"
    TYPE_6 = "TYPE VI - Black, very dark brown to black"

    def __init__(self, value):
        self.__schemaId = SchemaId(Namespace.NAMESPACE_ENUMS, "SkinColor")

    def getSchemaId(self) -> SchemaId:
        return self.__schemaId

    def getSchemaValue(self):
        return self.value
