#! /usr/bin/env python
# -*- coding: UTF-8 -*-

from enum import Enum


from .Namespace import Namespace
from ..SchemaId import SchemaId

class HairThickness(Enum):
    """
    length unit enumeration definition
    """
    NORMAL = "normal"
    THIN = "thin"
    THICK = "thick"


    def __init__(self, value):
        self.__schemaId = SchemaId(Namespace.NAMESPACE_ENUMS, "HairThickness")
    def getSchemaId(self) -> SchemaId:
        return self.__schemaId
    def getSchemaValue(self):
        return self.value
