#! /usr/bin/env python
# -*- coding: UTF-8 -*-

from enum import Enum


from .Namespace import Namespace
from ..SchemaId import SchemaId

class BodyLocation(Enum):
    """
    length unit enumeration definition
    """
    LEFT_ANKLE = "left ankle"
    RIGHT_ANKLE = "right ankle"
    LEFT_HIP = "left hip"
    RIGHT_HIP = "right hip"
    LEFT_THIGH = "left thigh"
    RIGHT_THIGH = "right thigh"
    LEFT_THORAX = "left thorax"
    MIDDLE_LEFT_THORAX = "middle left thorax"
    LEFT_UPPER_ARM = "left upper arm"
    RIGHT_UPPER_ARM = "right upper arm"
    LEFT_WRIST = "left wrist"
    RIGHT_WRIST = "right wrist"
    HANDS = "hands"
    FEETS = "feet"

    def __init__(self, value):
        self.__schemaId = SchemaId(Namespace.NAMESPACE_ENUMS, "BodyLocation")
    def getSchemaId(self) -> SchemaId:
        return self.__schemaId
    def getSchemaValue(self):
        return self.value
