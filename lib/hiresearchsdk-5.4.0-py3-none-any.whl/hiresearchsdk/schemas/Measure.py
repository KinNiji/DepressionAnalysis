#! /usr/bin/env python
# -*- coding: UTF-8 -*-

from .ISchemaSupport import ISchemaSupport
from .basictypes import TimeFrame
from .enums import DescriptiveStatistic


class Measure(ISchemaSupport):
    """
    measure definition. it's used to be base class for all measures
    """

    def __init__(self, timeFrame: TimeFrame = None, descriptiveStatistic: DescriptiveStatistic = None,
                 userNotes: str = None):
        self.timeFrame = timeFrame
        self.descriptiveStatistic = descriptiveStatistic
        self.userNotes = userNotes

    def getTimeFrame(self) -> TimeFrame:
        return self.timeFrame

    def getDescriptiveStatistic(self) -> DescriptiveStatistic:
        return self.descriptiveStatistic

    def getUserNotes(self) -> str:
        return self.userNotes

    def setTimeFrame(self, timeFrame: TimeFrame):
        self.timeFrame = timeFrame

    def setDescriptiveStatistic(self, descriptiveStatistic: DescriptiveStatistic):
        self.descriptiveStatistic = descriptiveStatistic

    def setUserNotes(self, userNotes: str):
        self.userNotes = userNotes
