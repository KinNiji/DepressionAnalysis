#! /usr/bin/env python
# -*- coding: UTF-8 -*-


class SchemaId(object):
    """
    schemaid definition
    """

    def __init__(self, namespace: str, type: str):
        """
        create a schemaid object
        :param namespace: namespace of this schema
        :param type: type of this schema
        """
        self.__namespace = namespace
        self.__type = type

    def get_namespace(self):
        return self.__namespace

    def get_type(self):
        return self.__type
