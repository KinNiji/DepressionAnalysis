#! /usr/bin/env python
# -*- coding: UTF-8 -*-

from enum import Enum


class AccelerationUnit(Enum):
    """
    Acceleration unit enumeration definition
    """
    RUN_SPEED = "m/s^2"
    def __init__(self, value):
        pass

    def getSchemaValue(self):
        return self.value
