#! /usr/bin/env python
# -*- coding: UTF-8 -*-

from enum import Enum


class ElectricalImpedanceUnit(Enum):
    """
    ElectricalImpedenceUnit enumeration definition "Ω" "KΩ" "MΩ""
    """
    Impedence_A = "Ω"
    Impedence_K = "KΩ"
    Impedence_M = "MΩ"

    def __init__(self, value):
        pass

    def getSchemaValue(self):
        return self.value