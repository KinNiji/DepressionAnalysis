#! /usr/bin/env python
# -*- coding: UTF-8 -*-

from enum import Enum


class LengthUnit(Enum):
    """
    length unit enumeration definition
    """
    FEMTOMETER = "fm"
    PICOMETER = "pm"
    NANOMETER = "nm"
    MICROMETER = "um"
    MILLIMETER = "mm"
    CENTIMETER = "cm"
    METER = "m"
    KILOMETER = "km"
    INCH = "in"
    FOOT = "ft"
    YARD = "yd"
    MILE = "mi"

    def __init__(self, value):
        pass

    def getSchemaValue(self):
        return self.value
