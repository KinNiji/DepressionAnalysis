#! /usr/bin/env python
# -*- coding: UTF-8 -*-

from enum import Enum


class MassUnit(Enum):
    """
    mass unit enumeration definition
    """
    FEMTOGRAM = "fg"
    PICOGRAM = "pg"
    NANOGRAM = "ng"
    MICROGRAM = "ug"
    MILLIGRAM = "mg"
    GRAM = "g"
    KILOGRAM = "kg"
    METRIC_TON = "Metric Ton"
    GRAIN = "gr"
    OUNCE = "oz"
    POUND = "lb"
    TON = "Ton"

    def __init__(self, value):
        pass

    def getSchemaValue(self):
        return self.value
