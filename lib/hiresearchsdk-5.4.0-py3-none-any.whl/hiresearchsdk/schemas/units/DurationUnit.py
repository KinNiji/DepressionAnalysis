#! /usr/bin/env python
# -*- coding: UTF-8 -*-

from enum import Enum


class DurationUnit(Enum):
    """
    duration unit enumeration definition
    """
    PICOSECOND = "ps"
    NANOSECOND = "ns"
    MICROSECOND = "us"
    MILLISECOND = "ms"
    SECOND = "sec"
    MINUTE = "min"
    HOUR = "h"
    DAY = "d"
    WEEK = "wk"
    MONTH = "Mo"
    YEAR = "yr"

    def __init__(self, value):
        pass

    def getSchemaValue(self):
        return self.value
