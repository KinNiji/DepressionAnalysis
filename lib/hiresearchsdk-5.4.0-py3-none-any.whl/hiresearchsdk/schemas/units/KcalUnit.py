#! /usr/bin/env python
# -*- coding: UTF-8 -*-

from enum import Enum


class KcalUnit(Enum):
    """
    calorie unit enumeration definition
    """
    CALORIE = "cal"
    KILOCALORIE = "kcal"

    def __init__(self, value):
        pass

    def getSchemaValue(self):
        return self.value
