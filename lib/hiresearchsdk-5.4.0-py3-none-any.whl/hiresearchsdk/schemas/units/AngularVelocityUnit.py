#! /usr/bin/env python
# -*- coding: UTF-8 -*-

from enum import Enum


class AngularVelocityUnit(Enum):
    """
    AngularVelocity unit enumeration definition
    """
    RAD_MERCURY = "rad/s"
    def __init__(self, value):
        pass

    def getSchemaValue(self):
        return self.value
