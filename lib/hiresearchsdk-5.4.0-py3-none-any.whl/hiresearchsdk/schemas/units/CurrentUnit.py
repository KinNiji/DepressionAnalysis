#! /usr/bin/env python
# -*- coding: UTF-8 -*-

from enum import Enum


class CurrentUnit(Enum):
    """
    CurrentUnit unit enumeration definition"kA","A","mA","μA","nA","pA"
    """
    CURRENT_KA = "kA"
    CURRENT_A = "A"
    CURRENT_MA = "mA"
    CURRENT_QA = "μA"
    CURRENT_NA = "nA"
    CURRENT_PA = "pA"

    def __init__(self, value):
        pass

    def getSchemaValue(self):
        return self.value
