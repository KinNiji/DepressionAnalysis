#! /usr/bin/env python
# -*- coding: UTF-8 -*-

from enum import Enum


class BloodGlucoseUnit(Enum):
    """
    blood glucose unit enumeration definition
    """
    MILLIGRAMS_PER_DECILITER = "mg/dL"
    MILLIMOLES_PER_LITER = "mmol/L"

    def __init__(self, value):
        pass

    def getSchemaValue(self):
        return self.value
