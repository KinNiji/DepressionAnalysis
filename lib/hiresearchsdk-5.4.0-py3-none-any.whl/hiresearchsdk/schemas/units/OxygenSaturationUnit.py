#! /usr/bin/env python
# -*- coding: UTF-8 -*-

from enum import Enum


class OxygenSaturationUnit(Enum):
    """
    OxygenSaturation unit enumeration definition
    """
    PER_CENT = "%"

    def __init__(self, value):
        pass

    def getSchemaValue(self):
        return self.value