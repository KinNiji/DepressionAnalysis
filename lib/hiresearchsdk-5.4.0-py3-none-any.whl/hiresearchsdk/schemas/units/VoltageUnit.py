#! /usr/bin/env python
# -*- coding: UTF-8 -*-

from enum import Enum


class VoltageUnit(Enum):
    """
    Voltage unit enumeration definition"kV","V","mV","μV","nV","pV"
    """
    VOL_KV = "kV"
    VOL_V = "V"
    VOL_MV = "mV"
    VOL_QV = "μV"
    VOL_NV = "nV"
    VOL_PV = "pV"

    def __init__(self, value):
        pass

    def getSchemaValue(self):
        return self.value