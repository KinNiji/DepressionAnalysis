#! /usr/bin/env python
# -*- coding: UTF-8 -*-

from enum import Enum


class TemperatureUnit(Enum):
    """
    Temperature unit enumeration definition
    """
    K_TEMP = "K"
    F_TEMP = "F"
    C_TEMP = "C"

    def __init__(self, value):
        pass

    def getSchemaValue(self):
        return self.value