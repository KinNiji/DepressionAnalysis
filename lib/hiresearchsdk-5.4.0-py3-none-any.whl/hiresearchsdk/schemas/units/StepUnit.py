#! /usr/bin/env python
# -*- coding: UTF-8 -*-

from enum import Enum


class StepUnit(Enum):
    """
    Step unit enumeration definition
    """
    STEPS = "steps"


    def __init__(self, value):
        pass

    def getSchemaValue(self):
        return self.value