#! /usr/bin/env python
# -*- coding: UTF-8 -*-

from enum import Enum


class HeartRateUnit(Enum):
    """
    heartrate unit enumeration definition
    """
    BEATS_PER_MINUTE = "beats/min"

    def __init__(self, value):
        pass

    def getSchemaValue(self):
        return self.value
