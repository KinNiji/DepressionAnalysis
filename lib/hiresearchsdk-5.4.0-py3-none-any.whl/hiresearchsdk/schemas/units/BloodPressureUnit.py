#! /usr/bin/env python
# -*- coding: UTF-8 -*-

from enum import Enum


class BloodPressureUnit(Enum):
    """
    blood pressure unit enumeration definition
    """
    MM_OF_MERCURY = "mmHg"
    def __init__(self, value):
        pass

    def getSchemaValue(self):
        return self.value
