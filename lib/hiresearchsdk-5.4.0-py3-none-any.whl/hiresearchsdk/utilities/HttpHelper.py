#! /usr/bin/env python
# -*- coding: UTF-8 -*-
import _io
import json
import os

import requests

from .Logger import Logger

# 屏蔽sdk调用https接口的告警错误
requests.packages.urllib3.disable_warnings()


def post(request_provider, url, request_body, request_header: dict = None, timeout=None):
    """
    发起post请求
    :param request_provider
    :param url:
    :param request_body:
    :param request_header:
    :param timeout:
    :return:
    """

    Logger().info("POST " + url + " " + str(request_body))

    if request_body is None:
        request_body = {}
    if request_header is None:
        request_header = {}
    if request_header.get("Content-Type") is None \
            or request_header.get("Accept") is None:
        request_header["Content-Type"] = "application/json"
        request_header["Accept"] = "application/json;charset=UTF-8"

    if type(request_body) == str:
        request_body = str(request_body).encode("utf8")
    else:
        request_body = json.dumps(request_body)

    response = request_provider.post(url, data=request_body, headers=request_header, verify=False, timeout=timeout)

    Logger().info("Response: StatusCode is %s , body is %s" % (response.status_code, response.text[:500]))

    # 返回码如果是4xx，5xx，这里会抛出异常
    response.raise_for_status()

    return response.text


def delete(request_provider, url, request_header: dict = None, timeout=None):
    """
    发起delete请求
    :param request_provider
    :param url:
    :param request_body:
    :param request_header:
    :param timeout:
    :return:
    """

    Logger().info("DELETE " + url)

    if request_header is None:
        request_header = {}
    if request_header.get("Content-Type") is None \
            or request_header.get("Accept") is None:
        request_header["Content-Type"] = "application/json"
        request_header["Accept"] = "application/json;charset=UTF-8"

    response = request_provider.delete(url, headers=request_header, verify=False, timeout=timeout)

    Logger().info("Response: StatusCode is %s , body is %s" % (response.status_code, response.text[:500]))

    # 返回码如果是4xx，5xx，这里会抛出异常
    response.raise_for_status()

    return response.text


def put(request_provider, url, request_body, request_header: dict = None, timeout=None,
        no_default_header: bool = False):
    """
    发起put请求
    :param request_provider
    :param url:
    :param request_body:
    :param request_header:
    :param timeout:
    :param no_default_header:
    :return:
    """

    Logger().info("PUT " + url + " " + str(request_body)[:100])

    if request_body is None:
        request_body = {}
    if request_header is None:
        request_header = {}

    if not no_default_header:
        if request_header.get("Content-Type") is None \
                or request_header.get("Accept") is None:
            request_header["Content-Type"] = "application/json"
            request_header["Accept"] = "application/json;charset=UTF-8"

    if type(request_body) == str:
        request_body = str(request_body).encode("utf8")
    elif type(request_body) == bytes:
        pass
    elif type(request_body) == _io.BufferedReader:
        # bugfix: his s3 bug: request_body must be none if zero-length file is uploaded
        file_size = os.fstat(request_body.fileno()).st_size
        if file_size == 0:
            request_body = None
    else:
        request_body = json.dumps(request_body)

    response = request_provider.put(url, data=request_body, headers=request_header, verify=False, timeout=timeout)

    Logger().info("Response: StatusCode is %s , body is %s" % (response.status_code, response.text[:500]))

    # 返回码如果是4xx，5xx，这里会抛出异常
    response.raise_for_status()

    return response.text


def get(request_provider, url, request_header=None, timeout=None, params: dict = None):
    """
    发起get请求
    :param request_provider
    :param url:
    :param request_header:
    :param timeout:
    :param params:
    :return:
    """
    Logger().info("GET " + url)

    if request_header is None:
        request_header = {}
    if request_header.get("Accept") is None:
        request_header["Accept"] = "application/json;charset=UTF-8"

    response = request_provider.get(url, headers=request_header, verify=False, timeout=timeout, params=params)

    Logger().info("Response: StatusCode is %s , body is %s" % (
        response.status_code, response.text[:500]))

    # 返回码如果是4xx，5xx，这里会抛出异常
    response.raise_for_status()

    return response.text


def get_file(request_provider, url, request_header=None, timeout=None, stream: bool = False):
    """
    发起get请求
    :param request_provider
    :param url:
    :param request_header:
    :param timeout:
    :param stream:
    :return:
    """
    Logger().info("GET " + url)

    if request_header is None:
        request_header = {}

    return request_provider.get(url, headers=request_header, verify=False, timeout=timeout, stream=stream)


def build_http_url(*parts):
    return "/".join(parts)
