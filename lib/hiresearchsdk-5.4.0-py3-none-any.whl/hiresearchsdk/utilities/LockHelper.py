#! /usr/bin/env python
# -*- coding: UTF-8 -*-

import threading

from .Logger import Logger


class LockHelper(object):

    def __init__(self, name: str, lock: threading.Lock):
        self.__name = name
        self.__lock = lock

    def acquire(self):
        Logger().info("获取%s锁" % self.__name)
        self.__lock.acquire(blocking=True)

    def release(self):
        if self.__lock.locked():
            Logger().info("释放%s锁" % self.__name)
            self.__lock.release()
