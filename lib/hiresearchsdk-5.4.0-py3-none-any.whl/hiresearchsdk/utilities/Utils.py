import json
import uuid
from enum import Enum

from ..config import BridgeConfig
from ..exceptions import CustomException, ErrorCodes


class Utils(object):
    @staticmethod
    def assert_not_none(param, name=None):
        """
        判断参数不能为空
        :param param:
        :param name:
        :return:
        """
        if param is None or (type(param) == str and param == "") or (type(param) == list and len(param) == 0):
            raise CustomException(ErrorCodes.ERR_CODE_PARAM_MUST_NOT_EMPTY,
                                  "参数 %s 不能为空！" % (name if name is not None else ""))

    @staticmethod
    def wrap_header_with_token(session_token, request_header):
        """
        交互后台接口，header都需要这个token
        :param session_token:
        :param request_header:
        :return:
        """
        if session_token is None or session_token == "":
            raise CustomException(ErrorCodes.ERR_CODE_NOT_AUTHED, "未通过授权！")

        request_header["Bridge-Session"] = session_token

    @staticmethod
    def wrap_header_with_token_v2(session_token: str, bridge_config: BridgeConfig, request_header):
        """
        交互后台接口，header都需要这个token
        :param session_token:
        :param bridge_config:
        :param request_header:
        :return:
        """
        if session_token is None or session_token == "":
            raise CustomException(ErrorCodes.ERR_CODE_NOT_AUTHED, "未通过授权！")

        request_header["Bridge-Session"] = session_token
        request_header["Project-Code"] = bridge_config.get_projectcode()
        request_header["User-Agent"] = bridge_config.get_useragent()

    @staticmethod
    def generate_uuid():
        """
        生成uuid
        :return:
        """
        return str(uuid.uuid1()).replace("-", "")

    @staticmethod
    def dumps(self) -> str:
        """
        format current object to json str
        :return: json str
        """

        # schemaId do not needed
        copy_dict = self.__dict__.copy()

        Utils.__prepare(copy_dict)

        return json.dumps(copy_dict)

    @staticmethod
    def __prepare(data_dict: dict):
        # delete none field
        Utils.__del_none_field(data_dict)

        for key, value in list(data_dict.items()):
            if Utils.__is_simple(value):
                continue

            if isinstance(value, Enum):
                data_dict[key] = value.value
                continue

            if isinstance(value, list):
                value_list = []
                for item in value:
                    value_list.append(item.__dict__)
                    Utils.__prepare(item.__dict__)
                data_dict[key] = value_list
            else:
                data_dict[key] = value.__dict__
                Utils.__prepare(value.__dict__)

    @staticmethod
    def __del_none_field(data):
        for key, value in list(data.items()):
            if value is None:
                del data[key]
            elif isinstance(value, dict):
                Utils.__del_none_field(value)

    @staticmethod
    def __is_simple(value):
        if isinstance(value, int) or isinstance(value, str) or isinstance(value, float) \
                or isinstance(value, dict) or isinstance(value, tuple):
            return True
        else:
            if (isinstance(value, list) and Utils.__is_simple(value[0])):
                return True

            return False
