#! /usr/bin/env python
# -*- coding: UTF-8 -*-
import os
import zipfile


class ZipHelper(object):
    """
    zip工具类
    """

    def zip_file_path(self, input_path, output_path):
        """
        压缩文件
        :param input_path: 压缩的文件夹路径
        :param output_path: 解压（输出）的路径
        :param output_name: 输出的压缩包绝对路径
        :return:
        """
        f = zipfile.ZipFile(output_path, 'w', zipfile.ZIP_DEFLATED)
        filelists = []
        self.__get_zip_file(input_path, filelists)
        for file in filelists:
            f.write(file)
        # 调用了close方法才会保证完成压缩
        f.close()
        return output_path

    def __get_zip_file(self, input_path, result):
        """
        对目录进行深度优先遍历
        :param input_path:
        :param result:
        :return:
        """
        if os.path.isdir(input_path):
            files = os.listdir(input_path)

            for file in files:
                if os.path.isdir(input_path + '/' + file):
                    self.__get_zip_file(input_path + '/' + file, result)
                else:
                    result.append(input_path + '/' + file)
        else:
            result.append(input_path)
