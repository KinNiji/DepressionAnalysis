#! /usr/bin/env python
# -*- coding: UTF-8 -*-

from enum import Enum


class Classification(Enum):
    """
    classification
    """
    BASIC = "basic"
    UNITS = "units"
    TIME = "time"
    PHYSICAL_ACTIVITY = "physicalactivity"
    VITALS = "vitals"
    SLEEP = "sleep"
    HEART = "heart"
    USERINFO = "userinfo"
    ACCESSORY = "accessory"
    SENSOR = "sensor"
    STATISTICS = "statistics"

    def __init__(self, value):
        pass

    def getBasicTypeName(self):
        return self.value
