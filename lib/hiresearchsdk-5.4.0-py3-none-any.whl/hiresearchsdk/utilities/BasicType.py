#! /usr/bin/env python
# -*- coding: UTF-8 -*-

from enum import Enum


class BasicType(Enum):
    """
    basic type
    """
    TEXT = "Text"
    ARRAY = "Array"
    DOUBLE = "Double"
    NUMBER = "Number"
    STRING = "String"
    BOOLEAN = "Boolean"
    INTEGER = "Integer"
    ATTACHMENT = "Attachment"
    OBJECT = "Object"
    UNITVALUE = "UnitValue"

    def __init__(self, value):
        pass

    def getBasicTypeName(self):
        return self.value
