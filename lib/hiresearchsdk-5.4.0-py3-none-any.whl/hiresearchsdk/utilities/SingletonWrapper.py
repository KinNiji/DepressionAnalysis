#! /usr/bin/env python
# -*- coding: UTF-8 -*-

import threading


class Singleton(type):
    """
    线程安全单例包装器
    """
    __singleton_lock = threading.Lock()

    def __init__(cls, *args, **kwargs):
        cls.__instance = None
        super().__init__(*args, **kwargs)

    def __call__(cls, *args, **kwargs):
        """
        实现线程安全单例
        :param args:
        :param kwargs:
        :return:
        """

        if cls.__instance is None:
            with cls.__singleton_lock:
                if cls.__instance is None:
                    cls.__instance = super().__call__(*args, **kwargs)
        return cls.__instance
