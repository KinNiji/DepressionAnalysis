import base64

# from Crypto.Cipher import AES

block_size = 16


class AESCBC:
    def __init__(self):
        self.pad = lambda s: s + (block_size - len(s) % block_size) * chr(block_size - len(s) % block_size)
        self.unpad = lambda s: s[0:-ord(s[-1:])]

    def decrypt_with_aes(self, encoded, secret_key, iv):
        cipher_text = encoded
        # secret_key = base64.b64decode(secret_key)
        #       cipher = AES.new(secret_key[:32], AES.MODE_CBC, base64.decodebytes(iv))
        #       plain_bytes = self.unpad(cipher.decrypt(cipher_text[block_size:]))
        return cipher_text
