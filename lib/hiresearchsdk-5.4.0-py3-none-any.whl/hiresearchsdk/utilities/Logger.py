#! /usr/bin/env python
# -*- coding: UTF-8 -*-
import logging.config
import logging.handlers
import os
from distutils.sysconfig import get_python_lib

from .SingletonWrapper import Singleton


class Logger(metaclass=Singleton):
    """
    日志工具类
    """

    def __init__(self):
        Logger.__init_logger()

    @staticmethod
    def __init_logger():
        with open(get_python_lib() + "/hiresearchsdk/config/logging.conf", encoding="utf8") as configfile:
            if not os.path.exists("./logs"):
                os.makedirs("./logs", exist_ok=True)

            logging.config.fileConfig(configfile)

    @staticmethod
    def __get_logger():
        return logging.getLogger("standardLogger")

    @staticmethod
    def debug(msg):
        Logger.__get_logger().debug(msg)

    @staticmethod
    def info(msg):
        Logger.__get_logger().info(msg)

    @staticmethod
    def warn(msg):
        Logger.__get_logger().warning(msg)

    @staticmethod
    def error(msg):
        Logger.__get_logger().error(msg)
