import os
import sys

from obs import ObsClient

from . import Consts
from .Logger import Logger
from ..exceptions import CustomException, ErrorCodes


class ObsHelper(object):
    """
    Obs访问器
    """

    def __init__(self, access_key_id: str, access_key_secret: str, security_token: str, endpoint: str,
                 bucket_name: str):
        """
        初始化oss客户端
        :param access_key_id:
        :param access_key_secret:
        :param security_token:
        :param endpoint:
        :param bucket_name:
        """
        self.__obsClient = ObsClient(
            access_key_id=access_key_id,
            secret_access_key=access_key_secret,
            security_token=security_token,
            server=endpoint
        )

        self.__bucket_name = bucket_name

    def get_object(self, object_key):
        """
        获取对象内容
        :param object_key:
        :return:
        """
        object_stream = None

        try:
            object_stream = self.__obsClient.getObject(self.__bucket_name, object_key, loadStreamInMemory=True)

            if object_stream.status < 300:
                Logger.info("对象%s获取成功" % object_stream)
            else:
                Logger.error("对象%s获取失败" % object_stream)
                Logger.error("errorCode：%s" % object_stream.errorCode)
                Logger.error("errorMessage：%s" % object_stream.errorMessage)
                Logger.error("requestId：%s" % object_stream.requestId)
                Logger.error("requestId：%s" % object_stream.hostId)

        except Exception as err:
            Logger.error(str(err))
            if err.status == 404:
                raise CustomException(ErrorCodes.ERR_CODE_CLOUD_ERROR, "%s资源不存在" % object_key).with_traceback(
                    sys.exc_info()[2])
            elif err.status == 403:
                raise CustomException(ErrorCodes.ERR_CODE_CLOUD_ERROR, "Access Denied").with_traceback(
                    sys.exc_info()[2])
            else:
                raise CustomException(ErrorCodes.ERR_CODE_CLOUD_ERROR, str(err.details)).with_traceback(
                    sys.exc_info()[2])

        return object_stream.body.buffer

    def list_objects(self, object_path, marker=""):
        """
        列举指定目录下对象
        :param object_path: 目录路径
        :param marker: 下次分页起始位置，首次不传或者传空字符串即可
        :return:
        """
        objects = self.__obsClient.listObjects(self.__bucket_name, prefix=object_path, marker=marker, max_keys=1000)

        if objects.status < 300:
            Logger.info("列举指定目录%s下对象成功" % object_path)
        else:
            Logger.error("列举指定目录%s下对象失败" % object_path)
            Logger.error("errorCode：%s" % objects.errorCode)
            Logger.error("errorMessage：%s" % objects.errorMessage)
            Logger.error("requestId：%s" % objects.requestId)
            Logger.error("requestId：%s" % objects.hostId)
        return objects

    def put_object(self, processed_objectpath: str, object_key: str, delete_after_upload: bool = False):
        """
        上传文件
        :param processed_objectpath:
        :param object_key:
        :param delete_after_upload:
        :return:
        """
        Logger.info("Start to upload file")

        # result of file upload
        putobject_result = None

        # upload to oss
        try:
            putobject_result = self.__obsClient.putFile(self.__bucket_name, object_key, processed_objectpath)
            if putobject_result.status < 300:
                Logger.info("上传对象%s成功" % object_key)
            else:
                Logger.error("上传对象%s成功" % object_key)
                Logger.error("errorCode：%s" % putobject_result.errorCode)
                Logger.error("errorMessage：%s" % putobject_result.errorMessage)
                Logger.error("requestId：%s" % putobject_result.requestId)
                Logger.error("requestId：%s" % putobject_result.hostId)
        except Exception as err:
            Logger.error(str(err))

            if err.status == 404:
                raise CustomException(ErrorCodes.ERR_CODE_CLOUD_ERROR, "%s资源不存在" % object_key).with_traceback(
                    sys.exc_info()[2])
            elif err.status == 403:
                raise CustomException(ErrorCodes.ERR_CODE_CLOUD_ERROR, "Access Denied").with_traceback(
                    sys.exc_info()[2])
            else:
                raise CustomException(ErrorCodes.ERR_CODE_CLOUD_ERROR, str(err.details)).with_traceback(
                    sys.exc_info()[2])
        finally:
            if delete_after_upload and os.path.exists(processed_objectpath):
                Logger.info("delete temp file")

                os.remove(processed_objectpath)

        return object_key.replace(Consts.FILES_UPLOADS_PREFIX, "", 1), putobject_result
