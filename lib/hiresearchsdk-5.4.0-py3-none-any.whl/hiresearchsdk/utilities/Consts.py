#! /usr/bin/env python
# -*- coding: UTF-8 -*-

AUTHTYPE_MEMBER = "memberauth"  # 授权方式，研究人员授权
AUTHTYPE_APPLICATION = "applicationauth"  # 授权方式，第三方应用授权

TABLES_VISITOR_TYPE_META = "meta"  # 研究数据表访问类型，元数据
TABLES_VISITOR_TYPE_ANALYSIS = "analysis"  # 研究数据表访问类型，分析数据

FILES_UPLOADS_PREFIX = "customuploads/"  # prefix of custom upload path

CLOUDTYPE_HIS = "his"
