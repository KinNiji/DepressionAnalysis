#! /usr/bin/env python
# -*- coding: UTF-8 -*-
from ..utilities import Utils


class BridgeConfig(object):
    __DEFAULT_VERSION = 3

    URL_SWITCHPROJECT = "studymanager/v1/users/switchProject"
    URL_GETADSINFO = "researchstudyservice/v1/tables/visitor"
    URL_ASSUMEROLE = "researchstudyservice/v1/study/assumeRole"
    URL_GETQUESTIONNAIREBYNAME = "bridgeservice/v1/questionnaires/name/{}"
    URL_CREATETABLE = "researchstudyservice/v1/tables"
    URL_SEARCHTABLEDATA = "researchstudyservice/v1/tables/{}/rows/filter"
    URL_WRITETABLEDATA = "researchstudyservice/v1/tables/data"
    URL_CLEARSCROLL = "researchstudyservice/v1/tables/clearScroll"
    URL_AUTH = "studymanager/v1/users/token/exchange"
    URL_AUTH_REFRESH = "studymanager/v1/users/token/refresh"
    URL_CREATE_FILE = "researchstudyservice/v1/files"

    HEADER_PROJECTCODE = "Project-Code"
    HEADER_SESSIONTOKEN = "Bridge-Session"

    PRODUCT_ALIYUN_DATAHUB = "datahub"
    PRODUCT_ALIYUN_TABLESTORE = "tablestore"
    PRODUCT_ALIYUN_OSS = "oss"

    PERMISSION_READ_ATTACHMENTS = "read_attachments"
    PERMISSION_READ_FILES = "read_files"
    PERMISSION_LIST_OBJECTS = "list_objects"
    PERMISSION_READ = "read"
    PERMISSION_UPLOAD = "upload"

    ENV_HIRESEARCH_TASKPATH = "HIRESEARCH_TASK_PATH"

    def __init__(self, project_code: str, env: str = "product"):
        Utils.assert_not_none(project_code, "研究项目编码")
        Utils.assert_not_none(env, "HiResearch后台接口地址")

        self.__project_code = project_code
        self.__project_switched = True

        self.set_env(env)

    def get_useragent(self):
        """
        获取useragent
        :return:
        """
        return "%s/%s(python) BridgeSDK/%s" % (self.__project_code, self.__DEFAULT_VERSION, self.__DEFAULT_VERSION)

    def get_projectcode(self):
        """
        获取研究项目编码
        :return:
        """
        return self.__project_code

    def set_projectcode(self, project_code):
        """
        设置研究项目编码
        :param project_code:
        :return:
        """
        if project_code != self.__project_code:
            self.__project_switched = True
            self.__project_code = project_code

    def get_baseurl(self):
        """
        获取baseurl
        :return:
        """
        return self.__base_url

    def get_baseurl_portal(self):
        """
        获取portal baseurl，用于登录
        :return:
        """
        return self.__base_url_portal

    def set_env(self, env):
        """
        设置环境
        :param env:
        :return:
        """
        if env == "alpha":
            self.__base_url = "https://hiresearch-alpha-api.cbg-app.huawei.com"
            self.__base_url_portal = "https://hiresearch-alpha.cbg-app.huawei.com"
        elif env == "beta":
            self.__base_url = "https://research-beta-kit.mafa301.com"
            self.__base_url_portal = "https://research-beta.mafa301.com/"
        elif env == "product":
            self.__base_url = "https://hiresearch-kit.cbg-app.huawei.com"
            self.__base_url_portal = "https://hiresearch.cbg-app.huawei.com/"
        elif env == "private":
            self.__base_url = "https://hiresearch-api-rnd.cbg-app.huawei.com"
            self.__base_url_portal = "https://hiresearch-portal-rnd.cbg-app.huawei.com"
