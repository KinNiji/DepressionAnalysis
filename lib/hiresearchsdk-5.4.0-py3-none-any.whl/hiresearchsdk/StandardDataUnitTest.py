import unittest
import logging

from schemas.standardfields.datapoints import TemperatureUnitValue, VoltageUnitValue, CurrentUnitValue, \
    AngularVelocityUnitValue, AccelerationUnitValue, KcalUnitValue
from schemas.standardfields.health import HeartRate, BloodGlucose

logging.basicConfig(format='%(asctime)s - %(pathname)s[line:%(lineno)d] - %(levelname)s: %(message)s',
                    level=logging.DEBUG)

if __name__ == '__main__':
    bloodGlucoseData = BloodGlucose.from_json({"date":20200627,"recordtime":1593431821119,"healthid":"hiresearch1053b7bac9ba437895e011591574f4b8","recordschema":"1","bloodGlucose":{"bloodGlucose ":{"unit":"mg/dL","value":3},"specimenSource ":"breath ","relationshipToMeal ":"before breakfast "},"uniqueid":"68faa75bb5334918b574779495634e0e20200627before breakfast","uploadtime":1593431821119});
    hearRateData = HeartRate.from_json({"heartRate ":{"unit":"beats/min","value":60},"specimenSource ":"breath ","relationshipToPhysicalActivity ":"before breakfast "});
    temperatureUnitData = TemperatureUnitValue.from_json({"unit":"C","value":37.1});
    voltageUnitData = VoltageUnitValue.from_json({"unit":"kV","value":220})
    currentUnitData = CurrentUnitValue.from_json({"unit": "kA", "value": 20})
    angularVelocityUnitData = AngularVelocityUnitValue.from_json({"unit": "", "value": 20})
    accelerationUnitData = AccelerationUnitValue.from_json({"unit": "rad/s", "value": 20})
    kcalUnitData = KcalUnitValue.from_json({"unit": "kcal", "value": 1300})

    logging.info(str(angularVelocityUnitData.value) + angularVelocityUnitData.unit)
