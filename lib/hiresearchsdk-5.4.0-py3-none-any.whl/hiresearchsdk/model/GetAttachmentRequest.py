#! /usr/bin/env python
# -*- coding: UTF-8 -*-

from .BridgeRequestBase import BridgeRequestBase

from ..utilities import Utils


class GetAttachmentRequest(BridgeRequestBase):
    """
    下载附件请求
    """

    def __init__(self, sessiontoken: str, attachment_handler: str, output_folder: str, table_id: str = None):
        """
        初始化
        :param sessiontoken: token
        :param attachment_handler: 附件标识
        :param output_folder: 输出路径
        :param table_id: 数据表id
        """
        super(GetAttachmentRequest, self).__init__(sessiontoken)

        Utils.assert_not_none(attachment_handler, "attachment_handler")
        Utils.assert_not_none(output_folder, "output_folder")

        self.__attachment_handler = attachment_handler

        self.__output_folder = output_folder

        self._table_id = table_id;

    def get_attachment_handler(self):
        return self.__attachment_handler

    def get_output_folder(self):
        return self.__output_folder

    def get_table_id(self):
        return self._table_id
