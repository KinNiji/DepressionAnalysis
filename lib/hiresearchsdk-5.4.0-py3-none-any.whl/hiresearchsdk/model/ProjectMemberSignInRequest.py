#! /usr/bin/env python
# -*- coding: UTF-8 -*-

from ..utilities import Utils


class ProjectMemberSignInRequest(object):
    def __init__(self, username: str, password: str):
        Utils.assert_not_none(username, "username")
        Utils.assert_not_none(password, "password")

        self.__username = username
        self.__password = password

    def get_username(self):
        return self.__username

    def get_password(self):
        return self.__password
