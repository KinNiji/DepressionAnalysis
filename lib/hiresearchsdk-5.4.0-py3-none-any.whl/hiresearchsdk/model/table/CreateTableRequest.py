#! /usr/bin/env python
# -*- coding: UTF-8 -*-

from ..BridgeRequestBase import BridgeRequestBase
from ...utilities import Utils


class CreateTableRequest(BridgeRequestBase):
    """
    创建研究数据表请求
    """

    def __init__(self, session_token: str, table_name: str, table_comment: str, field_list: list):
        super(CreateTableRequest, self).__init__(session_token)

        Utils.assert_not_none(table_name, "table_name")
        Utils.assert_not_none(table_comment, "table_comment")
        Utils.assert_not_none(field_list, "field_list")

        self.__table_name = table_name
        self.__table_comment = table_comment
        self.__field_list = field_list

    def get_table_name(self):
        return self.__table_name

    def get_table_comment(self):
        return self.__table_comment

    def get_field_list(self):
        return self.__field_list
