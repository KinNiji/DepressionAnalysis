#! /usr/bin/env python
# -*- coding: UTF-8 -*-


class AggregationInfo(object):
    """
    aggregation filter info
    """

    def __init__(self, aggregations: list = None, group_by_fields: list = None):
        """
        创建请求
        :param aggregations:  聚合操作列表
        :param group_by_fields: groupByFields
        """

        self.aggregations = aggregations
        self.groupByFields = group_by_fields
