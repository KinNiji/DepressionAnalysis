#! /usr/bin/env python
# -*- coding: UTF-8 -*-

from enum import Enum


class AggregationType(Enum):
    """
    aggregation filter operator enum definition
    """
    AVG = "avg"
    SUM = "sum"
    MAX = "max"
    MIN = "min"

    def __init__(self, value):
        pass
