#! /usr/bin/env python
# -*- coding: UTF-8 -*-
from ..BridgeRequestBase import BridgeRequestBase
from ...utilities import Utils


class WriteTableDataRequest(BridgeRequestBase):
    """
    数据写入请求。建议每行数据指定uniqueid字段，可以保证重复插入不会新增数据，而是覆盖数据。若不指定uniqueid，sdk会默认生成一个
    """

    def __init__(self, session_token: str, table_id: str, rows: list):
        """
        创建数据写入请求
        :param session_token: 用户登录接口获取的会话token
        :param table_id: 表id
        :param rows: 待写入数据行，类型必须为list<dict>
        """
        super(WriteTableDataRequest, self).__init__(session_token)

        Utils.assert_not_none(table_id, "table_id")
        Utils.assert_not_none(rows, "rows")

        # generate uniqueid if not exist
        for row in rows:
            if row.get("uniqueid"):
                continue
            row["uniqueid"] = Utils.generate_uuid()

        self.tableId = table_id
        self.dataRows = rows
