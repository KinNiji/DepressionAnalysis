#! /usr/bin/env python
# -*- coding: UTF-8 -*-
from . import AggregationInfo
from ..BridgeRequestBase import BridgeRequestBase
from ...utilities import Utils


class SearchTableDataRequest(BridgeRequestBase):
    """
    表数据查询请求
    """

    def __init__(self, session_token: str, table_id: str, filters: list = None,
                 aggregation_info: AggregationInfo = None, desired_size: int = None,
                 sorts: list = None, include_fields: list = None, exclude_fields: list = None,
                 giveup_when_more_than: int = None):
        """
        创建请求
        :param session_token:  用户登录接口获取的会话token
        :param table_id: 表id
        :param cursor: 聚合查询使用的分页依据
        :param filters:  过滤器列表
        :param aggregation_info:  聚合查询相关信息
        :param desired_size:  本次获取数据行数，不要超过5000
        :param sorts:  排序器列表
        :param include_fields: 需要包含的字段，不指定返回全部
        :param exclude_fields: 需要排除的字段，不指定不排除。请不要与include_filelds同时使用
        :param giveup_when_more_than: 当查询返回的结果条数大于指定条数时，放弃后续查询
        """

        super(SearchTableDataRequest, self).__init__(session_token)

        Utils.assert_not_none(table_id, "table_id")

        self.tableId = table_id
        self.filters = filters
        self.sorts = sorts
        self.desiredSize = desired_size
        self.includeFields = include_fields
        self.excludeFields = exclude_fields
        self.aggregationInfo = aggregation_info
        self.giveUpWhenMoreThan = giveup_when_more_than
