#! /usr/bin/env python
# -*- coding: UTF-8 -*-
from .AggregationType import AggregationType


class AggregationOperation(object):

    """
    aggregation filter operation
    """

    def __init__(self, field: str, aggregation_type: AggregationType):
        """
        :param field: 聚合操作字段名称
        :param aggregation_type: 聚合操作类型
        """
        self.field = field
        self.type = aggregation_type