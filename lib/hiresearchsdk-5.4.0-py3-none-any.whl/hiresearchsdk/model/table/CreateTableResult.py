#! /usr/bin/env python
# -*- coding: UTF-8 -*-


class CreateTableResult(object):
    """
    创建研究数据表的结果
    """

    def __init__(self, table_id: str):
        self.__table_id = table_id

    def get_table_id(self):
        """
        获取研究数据表id
        :return:
        """
        return self.__table_id
