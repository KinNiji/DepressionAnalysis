#! /usr/bin/env python
# -*- coding: UTF-8 -*-

from .BridgeRequestBase import BridgeRequestBase
from ..exceptions import CustomException, ErrorCodes
from ..utilities import Utils


class UploadObjectRequest(BridgeRequestBase):
    """
    上传对象请求
    """

    def __init__(self, sessiontoken: str, objectpath: str, destpath: str, file_need_zip: bool = False):
        """
        初始化
        :param sessiontoken: token
        :param objectpath: 对象路径，可以是一个文件路径，也可以是目录
        :param destpath: 上传文件目标目录
        :param file_need_zip: 上传文件时，可以设置是否需要压缩文件，默认不压缩；上传目录时，该配置项无效，目录一定会被压缩
        """
        super(UploadObjectRequest, self).__init__(sessiontoken)

        Utils.assert_not_none(objectpath, "objectpath")
        Utils.assert_not_none(destpath, "destpath")

        self.__objectpath = objectpath

        # validate special characters
        if destpath.find(":") >= 0 or destpath.find("\\") >= 0 or \
                destpath.find(r'"') >= 0 or destpath.find("+") >= 0 or destpath.find("$") >= 0:
            raise CustomException(ErrorCodes.ERR_CODE_UPLOAD_PATH_INVALID, r'上传目的路径不能包含 \ $ " : +')

        # validate dest path
        trimed_destpath = destpath.strip()

        # remove first /
        if trimed_destpath[0] == "/":
            trimed_destpath = trimed_destpath[1:]

        # check whether there is an empty folder in the path
        parts = trimed_destpath.split("/")
        for idx, part in enumerate(parts, start=0):
            if idx == 0 or idx == len(parts):
                continue
            if part.strip() == "":
                raise CustomException(ErrorCodes.ERR_CODE_UPLOAD_PATH_INVALID, "上传目的路径中包含空目录！")

        if trimed_destpath[len(trimed_destpath) - 1] == "/":
            raise CustomException(ErrorCodes.ERR_CODE_UPLOAD_PATH_INVALID, "上传目的路径需要精确到文件名！")

        self.__destpath = trimed_destpath

        self.__file_need_zip = file_need_zip

    def get_objectpath(self):
        return self.__objectpath

    def get_destpath(self):
        return self.__destpath

    def get_file_need_zip(self):
        return self.__file_need_zip
