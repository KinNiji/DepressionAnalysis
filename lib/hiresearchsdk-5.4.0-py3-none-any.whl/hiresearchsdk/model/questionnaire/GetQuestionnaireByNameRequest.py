#! /usr/bin/env python
# -*- coding: UTF-8 -*-

from ..BridgeRequestBase import BridgeRequestBase
from ...utilities import Utils


class GetQuestionnaireByNameRequest(BridgeRequestBase):
    """
    根据名称获取问卷信息
    """

    def __init__(self, session_token: str, name: str):
        """
        初始化请求
        :param session_token: 会话token
        :param name: 问卷名称
        """
        super(GetQuestionnaireByNameRequest, self).__init__(session_token)

        Utils.assert_not_none(name, "name")

        self.__name = name

    def get_name(self):
        return self.__name
