#! /usr/bin/env python
# -*- coding: UTF-8 -*-

from ..utilities import Utils


class AuthResponse(object):
    def __init__(self, accessToken: str, refreshToken: str, accessTokenDurationInMillis: int, refreshTokenDurationInMillis: int):
        Utils.assert_not_none(accessToken, "accessToken")
        Utils.assert_not_none(refreshToken, "refreshToken")
        Utils.assert_not_none(accessTokenDurationInMillis, "accessTokenDurationInMillis")
        Utils.assert_not_none(refreshTokenDurationInMillis, "refreshTokenDurationInMillis")

        self.__accessToken = accessToken
        self.__refreshToken = refreshToken
        self.__accessTokenDurationInMillis = accessTokenDurationInMillis
        self.__refreshTokenDurationInMillis = refreshTokenDurationInMillis

    def get_accessToken(self):
        return self.__accessToken

    def get_refreshToken(self):
        return self.__refreshToken

    def get_accessTokenDurationInMillis(self):
        return self.__accessTokenDurationInMillis

    def get_refreshTokenDurationInMillis(self):
        return self.__refreshTokenDurationInMillis
