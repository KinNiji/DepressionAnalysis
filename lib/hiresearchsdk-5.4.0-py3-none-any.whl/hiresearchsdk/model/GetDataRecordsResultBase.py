#! /usr/bin/env python
# -*- coding: UTF-8 -*-


class GetDataRecordsResultBase(object):
    def __init__(self, records: list):
        self.__records = records

    def get_records(self):
        return self.__records
