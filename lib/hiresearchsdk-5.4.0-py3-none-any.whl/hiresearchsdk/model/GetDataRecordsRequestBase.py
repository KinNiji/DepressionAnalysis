#! /usr/bin/env python
# -*- coding: UTF-8 -*-
from .BridgeRequestBase import BridgeRequestBase

from ..utilities import Utils


class GetDataRecordsRequestBase(BridgeRequestBase):
    def __init__(self, sessiontoken: str, tablename: str, columns_to_get: list = None):
        super(GetDataRecordsRequestBase, self).__init__(sessiontoken)

        Utils.assert_not_none(tablename, "tablename")

        self.__tablename = tablename
        self.__columns_to_get = columns_to_get

    def get_tablename(self):
        return self.__tablename

    def get_columns_to_get(self):
        return self.__columns_to_get
