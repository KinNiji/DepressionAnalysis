#! /usr/bin/env python
# -*- coding: UTF-8 -*-

import datetime
import time


class AssumedAuthInfo(object):
    """
    临时授权
    """

    def __init__(self, endpoint: str, key: str, secret: str, securitytoken: str, expired_unixtime: datetime.datetime):
        self.__endpoint = endpoint
        self.__key = key
        self.__secret = secret
        self.__securitytoken = securitytoken
        self.__expired_unixtime = time.mktime(expired_unixtime.timetuple())

    def get_endpoint(self):
        return self.__endpoint

    def get_key(self):
        return self.__key

    def get_secret(self):
        return self.__secret

    def get_securitytoken(self):
        return self.__securitytoken

    def is_expired(self):
        """
        是否超期了
        :return:
        """
        return time.mktime(datetime.datetime.now().timetuple()) >= self.__expired_unixtime
