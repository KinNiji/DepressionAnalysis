#! /usr/bin/env python
# -*- coding: UTF-8 -*-
from .AuthRequest import AuthRequest
from ..utilities import Utils


class RefreshAuthRequest(AuthRequest):
    def __init__(self, accessKey: str, secretKey: str, refreshToken: str):
        AuthRequest.__init__(self, accessKey, secretKey)
        Utils.assert_not_none(refreshToken, "refreshToken")

        self.__refreshToken = refreshToken

    def get_refreshToken(self):
        return self.__refreshToken
