#! /usr/bin/env python
# -*- coding: UTF-8 -*-

from .BridgeRequestBase import BridgeRequestBase


class ListObjectResponse(BridgeRequestBase):
    """
    列举对象列表的响应
    """

    def __init__(self, objects: list, next_marker: str):
        """
        对象
        :param objects:
        :param next_marker:
        """
        self.__objects = objects
        self.__next_marker = next_marker

    def get_objects(self):
        """
        获取对象列表
        :return:
        """
        return self.__objects

    def get_next_marker(self):
        """
        获取下页标识，如果为空，代表已经全部获取完了
        :return:
        """
        return self.__next_marker
