from .BridgeRequestBase import BridgeRequestBase
from ..exceptions import CustomException, ErrorCodes
from ..utilities.Utils import Utils


class ListObjectRequest(BridgeRequestBase):
    """
    列举对象请求
    """

    def __init__(self, sessiontoken: str, objectpath: str, marker: str = "", target_projectCode: str = None):
        """
        初始化
        :param sessiontoken: token
        :param objectpath: 对象路径，必须是一个目录路径
        :param marker: 起始位置，初始可不传或者传空
        """
        super(ListObjectRequest, self).__init__(sessiontoken)

        Utils.assert_not_none(objectpath, "objectpath")

        # validate special characters
        if objectpath.find(":") >= 0 or objectpath.find("\\") >= 0:
            raise CustomException(ErrorCodes.ERR_CODE_UPLOAD_PATH_INVALID, "目的路径不能包含英文冒号与反斜杠！")

        # validate dest path
        trimed_destpath = objectpath.strip()

        # remove first /
        if trimed_destpath[0] == "/":
            trimed_destpath = trimed_destpath[1:]

        # check whether there is an empty folder in the path
        parts = trimed_destpath.split("/")
        for idx, part in enumerate(parts, start=0):
            if idx == 0 or idx == len(parts):
                continue
            if part.strip() == "" and idx != len(parts) - 1:
                raise CustomException(ErrorCodes.ERR_CODE_UPLOAD_PATH_INVALID, "目的路径中包含空目录！")

        if trimed_destpath != "" and trimed_destpath[len(trimed_destpath) - 1] != "/":
            raise CustomException(ErrorCodes.ERR_CODE_UPLOAD_PATH_INVALID, "目的路径必需为目录路径，而非文件路径！")

        self.__objectpath = trimed_destpath

        self.__marker = marker

        self._targetprojectCode = target_projectCode

    def get_objectpath(self):
        return self.__objectpath

    def get_marker(self):
        return self.__marker

    def get_target_projectCode(self):
        return self._targetprojectCode
