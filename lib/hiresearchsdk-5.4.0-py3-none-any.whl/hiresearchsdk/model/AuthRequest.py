#! /usr/bin/env python
# -*- coding: UTF-8 -*-

from ..utilities import Utils


class AuthRequest(object):
    def __init__(self, accessKey: str, secretKey: str):
        Utils.assert_not_none(accessKey, "accessKey")
        Utils.assert_not_none(secretKey, "secretKey")

        self.__accessKey = accessKey
        self.__secretKey = secretKey

    def get_accessKey(self):
        return self.__accessKey

    def get_secretKey(self):
        return self.__secretKey
