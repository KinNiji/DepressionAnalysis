#! /usr/bin/env python
# -*- coding: UTF-8 -*-

from ..utilities.Utils import Utils


class BridgeRequestBase(object):
    """
    BridgeSDK需要验证授权信息的请求的基类
    """

    def __init__(self, sessiontoken: str):
        Utils.assert_not_none(sessiontoken, "sessiontoken")
        self.__sessiontoken = sessiontoken

    def get_sessiontoken(self):
        return self.__sessiontoken

    def set_sessiontoken(self, sessiontoken):
        self.__sessiontoken = sessiontoken
