#! /usr/bin/env python
# -*- coding: UTF-8 -*-
import traceback

from .CustomException import CustomException

ERR_CODE_CONFIGERR = "001"  # 配置错误

ERR_CODE_TABLE_FIELD_NOT_EXIST = "002"  # 表字段定义不存在

ERR_CODE_NOT_AUTHED = "003"  # 未通过鉴权

ERR_CODE_FIELD_NOT_EXIST_IN_META = "004"  # 元数据中不存在该字段

ERR_CODE_FIELD_TYPE_NOT_MATCH = "005"  # 该字段类型与元数据不匹配

ERR_CODE_TOPIC_NOT_FOUND = "006"  # topic不存在，请联系管理员

ERR_CODE_PARAM_MUST_NOT_EMPTY = "007"  # 参数不能为空

ERR_CODE_PARAM_REQ_NOT_MATCH = "008"  # 参数类型与指定不符

ERR_CODE_CLOUD_ERROR = "009"  # 公有云组件返回异常

ERR_CODE_UPLOAD_PATH_INVALID = "010"  # 非法上传路径

ERR_CODE_TEXT_FROM_DIFFERENT_TABLE = "011"  # 不同表的text handler

ERR_CODE_TEXT_FROM_DIFFERENT_FIELD = "012"  # 不同字段的text handler

ERR_CODE_PARAM_LENGTH_EXCEEDED = "013"  # 参数超长

ERR_CODE_ATTACHMENT_SIG_NOT_MATCH = "014"  # 附件签名校验失败

ERR_CODE_INTERNAL = "999"  # 内部错误


def get_err_msg(exception: object):
    """
    获取错误信息
    :param exception:
    :return:
    """
    if type(exception) == CustomException:
        return "错误码:%s 错误信息:%s 堆栈:%s" % (exception.errorCode, exception.message, traceback.format_exc())
    else:
        return "错误码:%s 错误信息:%s 堆栈:%s" % (
            ERR_CODE_INTERNAL, exception.message if hasattr(exception, "message") else str(exception),
            traceback.format_exc())
