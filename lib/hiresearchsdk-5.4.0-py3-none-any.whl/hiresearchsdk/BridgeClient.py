#! /usr/bin/env python
# -*- coding: UTF-8 -*-

from .config import BridgeConfig, HttpClientConfig

from .provider import ApiClientProvider, AuthenticationProvider, BridgeDataProvider
from .utilities import Utils


class BridgeClient(object):
    """
    封装了与Hiresearchcloud的交互
    """

    def __init__(self, bridgeconfig: BridgeConfig, httpclientconfig: HttpClientConfig = None):
        """
        构造器
        :param bridgeconfig: bridge配置
        :param httpclientconfig: http配置
        """
        Utils.assert_not_none(bridgeconfig, "bridgeconfig")

        self.__bridgeconfig = bridgeconfig
        self.__httpclientconfig = httpclientconfig

        self.__apiclient_provider = ApiClientProvider(httpclientconfig)

        self.__auth_provider = AuthenticationProvider(self.__bridgeconfig, self.__httpclientconfig,
                                                      self.__apiclient_provider)
        self.__bridgedata_provider = BridgeDataProvider(self.__bridgeconfig, self.__httpclientconfig,
                                                        self.__apiclient_provider)

    def get_bridgeconfig(self):
        """
        获取bridge配置
        :return:
        """
        return self.__bridgeconfig

    def get_httpclientconfig(self):
        """
        获取http配置
        :return:
        """
        return self.__httpclientconfig

    def get_authenticate_provider(self):
        """
        获取授权api
        :return:
        """
        return self.__auth_provider

    def get_bridgedata_provider(self):
        """
        获取数据api
        :return:
        """
        return self.__bridgedata_provider
