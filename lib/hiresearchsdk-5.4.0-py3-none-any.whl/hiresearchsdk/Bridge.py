#! /usr/bin/env python
# -*- coding: UTF-8 -*-
import datetime
import json
import threading

from apscheduler.schedulers.background import BackgroundScheduler
from tablestore import CompositeColumnCondition, ColumnCondition, SingleColumnCondition, ComparatorType, LogicalOperator

from .exceptions import CustomException
from .exceptions import ErrorCodes
from .utilities import ConfigManager
from .utilities import DatahubHelper
from .utilities import HttpHelper, Consts
from .utilities import LockHelper
from .utilities import Logger
from .utilities import OtsHelper
from .utilities import Singleton


class Bridge(metaclass=Singleton):
    """
    封装了与Hiresearchcloud的交互
    """

    def __init__(self):
        # 存储观察者
        self.__observors = []

        # 产品名称
        self.__productname_datahub = ConfigManager().get("aliyunproduct", "datahub")
        self.__productname_tablestore = ConfigManager().get("aliyunproduct", "tablestore")

        # 研究人员授权使用的信息
        self.__projectCode = ""
        self.__username = ""
        self.__password = ""

        # 第三方应用授权使用的信息
        self.__appKeyId = ""
        self.__appKeySecret = ""
        self.__accessToken = ""
        self.__refreshToken = ""
        self.__healthId = ""  # 第三方应用授权之后只能获取单个用户的数据，所以需要携带这个id

        # 授权类型 authcode 与 projectmember
        self.__authtype = ""

        # 与后台交互用的token
        self.__sessionToken = None
        self.__memberInfo = None

        # 数据类型与阿里云访问信息的配置
        self.__datatype_to_aliyunaccessinfo = {}
        # 产品类型与临时授权
        self.__product_to_authed = {}

        # tablestore封装
        self.__ots_helper: OtsHelper = None
        # datahub封装
        self.__datahub_helper: DatahubHelper = None

        # 观察者
        self.__observers = []

        # 延时任务调度，用于刷新授权
        self.__scheduler = BackgroundScheduler()
        self.__scheduler.start()

        # 生成锁，防止刷新客户端时，还有使用客户端的操作
        self.__ots_lock = LockHelper("tablestore", threading.Lock())
        self.__datahub_lock = LockHelper("datahub", threading.Lock())

    def auth_by_projectmember(self, project_code: str, username: str, password: str):
        """
        对外暴露的授权方法，使用研究人员授权
        :param project_code:  项目编码
        :param username: 研究人员用户名
        :param password: 研究人员密码
        :return:
        """
        if project_code is None or project_code == "" or username is None or username == "" \
                or password is None or password == "":
            raise CustomException(ErrorCodes.ERR_CODE_CONFIGERR, "项目编码、研究人员用户名&密码均不能为空")

        self.__projectCode = project_code
        self.__username = username
        self.__password = password

        self.__sessionToken = ""

        # 研究人员授权方式
        self.__authtype = Consts.AUTHTYPE_MEMBER

        self.__refresh_auth()

    def auth_by_application(self, project_code: str, app_key_id: str, app_key_secret: str, authcode: str,
                            identifier: str = None):
        """
        对外暴露的授权方法，用于第三方应用授权
        :param project_code: 项目编码
        :param app_key_id: app应用id
        :param app_key_secret: app应用密钥
        :param authcode: access_token
        :param identifier: 标识符，HiResearch会回传给第三方回调接口
        :return:
        """
        if project_code is None or project_code == "" or app_key_id is None or app_key_id == "" or app_key_secret is None or app_key_secret == "" or \
                authcode is None or authcode == "":
            raise CustomException(ErrorCodes.ERR_CODE_CONFIGERR, "项目编码、app应用id&密钥，授权码均不能为空")

        # 研究人员授权方式
        self.__authtype = Consts.AUTHTYPE_APPLICATION

        self.__sessionToken = ""
        self.__projectCode = project_code
        self.__appKeyId = app_key_id
        self.__appKeySecret = app_key_secret

        self.__trigger_get_accesstoken(authcode, identifier)

    def reauth_by_application(self, identifier: str):
        """
        对外暴露的授权方法，用于刷新第三方应用授权
        :param identifier: 标识符，HiResearch会回传给第三方回调接口
        :return:
        """
        # 研究人员授权方式
        self.__authtype = Consts.AUTHTYPE_APPLICATION

        self.__sessionToken = ""

        self.__trigger_refresh_accesstoken(identifier)

    def set_application_auth_info(self, access_token: str, refresh_token: str, health_id: str):
        """
        将HiResearch返回的第三方应用授权信息设置给SDK
        :param access_token: access_token
        :param refresh_token: refresh_token
        :param health_id: health_id
        :return:
        """
        if access_token is None or access_token == "" or refresh_token is None or refresh_token == "" or health_id \
                is None or health_id == "":
            raise CustomException(ErrorCodes.ERR_CODE_CONFIGERR, "app应用id&密钥均不能为空")

        self.__accessToken = access_token
        self.__refreshToken = refresh_token
        self.__healthId = health_id

        self.__sessionToken = access_token

        # 获取访问阿里云服务的临时授权
        self.__assume_role()

    def get_datarows(self, table_name: str, colums_to_get: list = None, filters: CompositeColumnCondition = None,
                     num_rows: int = None, page_callback=None) -> list:
        """
        获取多行数据
        :param table_name: 元数据名称
        :param colums_to_get: 需要获取的表字段，如果为空，则获取表的全部字段
        :param filters: 过滤条件，如果为空，则不过滤
        :param num_rows: 指定获取行数
        :param page_callback: 分页获取回调函数，如果传递了回调函数，那么get_datarows不会返回数据行，分页获取到的数据直接传入了回调函数中
        :return:
        """
        self.__get_download_info(table_name)

        tablename = self.__datatype_to_aliyunaccessinfo["download_" + table_name]["otsTableName"]
        tableschema = self.__datatype_to_aliyunaccessinfo["download_" + table_name]["tableSchema"]

        # 获取元数据与数据表字段的映射
        table_to_meta = {}
        meta_to_table = {}
        for field in tableschema:
            meta_to_table[field["metadataName"].lower()] = {"name": field["name"], "type": field["metadataType"]}
            table_to_meta[field["name"]] = field["metadataName"].lower()

        # 存储结果
        result_rows = []

        try:
            # 检查字段是否存在
            meta_columns_to_get = []
            if colums_to_get is not None:
                for colum_to_get in colums_to_get:
                    if table_to_meta.get(colum_to_get) is None:
                        raise CustomException(ErrorCodes.ERR_CODE_TABLE_FIELD_NOT_EXIST,
                                              "表字段 %s 不存在，请检查研究管理平台中的表字段配置" % colum_to_get)
                    meta_columns_to_get.append(table_to_meta.get(colum_to_get).lower())
            else:
                meta_columns_to_get = [item.lower() for item in list(table_to_meta.values())]

            datarows = self.__ots_helper.query_rows(tablename,
                                                    meta_columns_to_get if len(meta_columns_to_get) > 0 else None,
                                                    self.__translate_filters(filters, table_to_meta),
                                                    num_rows,
                                                    page_callback is not None,
                                                    meta_to_table,
                                                    lambda meta, results: page_callback(
                                                        Bridge.__translate_datarows(meta, results)), self.__ots_lock)

            # 结果元数据字段翻译为表字段
            result_rows = self.__translate_datarows(meta_to_table, datarows)

        except Exception as err:
            Logger().error("获取数据失败，" + ErrorCodes.get_err_msg(err))
        finally:
            self.__ots_lock.release()

        return result_rows

    def put_datarows(self, meta_data: str, version: str, records: list, devicemac: str = None):
        """
        上传数据到阿里云，暂未开放，请勿调用
        :param meta_data: 元数据名称
        :param version: 元数据版本
        :param records: 数据记录
        :param devicemac: 上传数据设备的mac地址，可缺省忽略
        :return:
        """
        self.__get_upload_info(meta_data, version)

        project = self.__datatype_to_aliyunaccessinfo["upload_" + meta_data]["projectName"]
        topic = self.__datatype_to_aliyunaccessinfo["upload_" + meta_data]["topicName"]
        schema = self.__datatype_to_aliyunaccessinfo["upload_" + meta_data]["recordSchema"]

        self.__datahub_lock.acquire()
        try:
            self.__datahub_helper.upload_records(project, topic, records, schema, self.__healthId, devicemac)
        except Exception as err:
            Logger().error("上传数据失败，" + ErrorCodes.get_err_msg(err))
        finally:
            self.__datahub_lock.release()

    def __refresh_auth(self):
        """
        刷新授权信息
        :return:
        """

        # 获取访问hiresearch后台的授权
        self.__get_accesstoken()

        # 获取访问阿里云服务的临时授权
        self.__assume_role()

    def __get_accesstoken(self):
        """
        获取鉴权信息
        :return:
        """
        request_body = {
            "projectCode": self.__projectCode,
            "name": self.__username,
            "password": self.__password
        }

        result = HttpHelper.post(HttpHelper.build_http_url(ConfigManager().get("requests", "login")), request_body)

        login_ret = json.loads(result, encoding="utf8")
        self.__sessionToken = login_ret["sessionToken"]
        self.__memberInfo = login_ret["memberInfo"]

    def __trigger_get_accesstoken(self, authcode, identifier):
        """
        触发oauth2获取授权信息
        :return:
        """

        request_body = {
            "appKeyId": self.__appKeyId,
            "appKeySecret": self.__appKeySecret,
            "authCode": authcode,
            "identifier": identifier
        }

        HttpHelper.put(HttpHelper.build_http_url(ConfigManager().get("requests", "exchangeForAccessToken")),
                       request_body)

    def __trigger_refresh_accesstoken(self, identifier):
        """
        触发oauth2刷新授权信息
        :return:
        """

        request_body = {
            "appKeyId": self.__appKeyId,
            "appKeySecret": self.__appKeySecret,
            "refreshToken": self.__refreshToken,
            "identifier": identifier
        }

        HttpHelper.put(HttpHelper.build_http_url(ConfigManager().get("requests", "refreshForAccessToken")),
                       request_body)

    def __assume_role(self):
        """
        获取临时授权信息
        :return:
        """

        Logger().info("获取datahub临时授权")
        self.__get_assumed_role(self.__productname_datahub, "upload")

        Logger().info("获取tablestore临时授权")
        self.__get_assumed_role(self.__productname_tablestore, "read")

    def __get_upload_info(self, meta_data, version):
        """
        获取指定数据类型的阿里云访问信息
        :param meta_data
        :param version
        :return:
        """
        key = "upload_" + meta_data
        if self.__datatype_to_aliyunaccessinfo.get(key) is not None:
            return

        Logger().info("获取数据上传所需信息")
        url = HttpHelper.build_http_url(
            ConfigManager().get("requests", "getUploadInfo").format(projectCode=self.__projectCode,
                                                                    dataType=meta_data, version=version))
        request_header = {}
        self.__wrap_header_with_token(request_header)
        result = HttpHelper.get(url, request_header)
        info_ret = json.loads(result, encoding="utf8")

        self.__datatype_to_aliyunaccessinfo[key] = {}
        self.__datatype_to_aliyunaccessinfo[key]["projectName"] = info_ret["projectName"]
        self.__datatype_to_aliyunaccessinfo[key]["topicName"] = info_ret["topicName"]
        self.__datatype_to_aliyunaccessinfo[key]["recordSchema"] = info_ret["recordSchema"]

        # 初始化datahub，并添加为观察者
        self.__datahub_helper = DatahubHelper(self.__product_to_authed[self.__productname_datahub]["endpoint"],
                                              self.__product_to_authed[self.__productname_datahub]["accessKeyId"],
                                              self.__product_to_authed[self.__productname_datahub][
                                                  "accessKeySecret"],
                                              self.__product_to_authed[self.__productname_datahub]["securityToken"]
                                              )
        self._register(self.__datahub_helper)

    def __get_download_info(self, table_name):
        """
        获取指定数据类型的阿里云访问信息
        :param table_name:
        :return:
        """
        key = "download_" + table_name
        if self.__datatype_to_aliyunaccessinfo.get(key) is not None:
            return

        Logger().info("获取数据下载所需信息")
        url = HttpHelper.build_http_url(
            ConfigManager().get("requests", "getDownloadInfo").format(projectCode=self.__projectCode,
                                                                      tableName=table_name))

        request_header = {}
        self.__wrap_header_with_token(request_header)
        result = HttpHelper.get(url, request_header)
        info_ret = json.loads(result, encoding="utf8")
        self.__datatype_to_aliyunaccessinfo[key] = {}
        self.__datatype_to_aliyunaccessinfo[key]["otsInstanceName"] = info_ret["otsInstanceName"]
        self.__datatype_to_aliyunaccessinfo[key]["otsTableName"] = info_ret["otsTableName"]
        self.__datatype_to_aliyunaccessinfo[key]["tableSchema"] = info_ret["tableSchema"]

        # 初始化tablestore，并添加为观察者
        self.__ots_helper = OtsHelper(self.__product_to_authed[self.__productname_tablestore]["endpoint"],
                                      self.__product_to_authed[self.__productname_tablestore]["accessKeyId"],
                                      self.__product_to_authed[self.__productname_tablestore]["accessKeySecret"],
                                      self.__datatype_to_aliyunaccessinfo[key]["otsInstanceName"],
                                      self.__product_to_authed[self.__productname_tablestore]["securityToken"])
        self._register(self.__ots_helper)

    def __get_assumed_role(self, product, permission):
        """
        获取产品临时授权
        :param product:
        :param permission:
        :return:
        """
        refresh_assumerole_task = "refresh_assumerole_" + product
        existing_job = self.__scheduler.get_job(refresh_assumerole_task)
        if existing_job is not None:
            Logger().info(product + "角色未过期，无需刷新")
            return

        if product == self.__productname_datahub:
            self.__datahub_lock.acquire()
        elif product == self.__productname_tablestore:
            self.__ots_lock.acquire()

        try:
            url = HttpHelper.build_http_url(
                str.format(ConfigManager().get("requests", "assumeRole")))

            request_header = {}
            self.__wrap_header_with_token(request_header)

            request_body = {
                "product": product,
                "permission": permission
            }

            result = HttpHelper.post(url, request_body, request_header)

            info_ret = json.loads(result, encoding="utf8")

            self.__product_to_authed[product] = info_ret

            # 授权发生变更，需要通知观察者变更
            self._notify({
                "type": product,
                "role": self.__product_to_authed[product]
            })
        except Exception as err:
            Logger().error(product + "客户端刷新失败，" + ErrorCodes.get_err_msg(err))
        finally:
            if product == self.__productname_datahub:
                self.__datahub_lock.release()
            elif product == self.__productname_tablestore:
                self.__ots_lock.release()

        expiration_time = info_ret["expiration"]
        if expiration_time is None or expiration_time == "":
            # 没有超时时间，不去刷新
            return

        # 超时时间与北京时间存在8效时滞后，所以加上8小时。减去10min是为了确保在失效前重新获取
        trigger_time = datetime.datetime.strptime(expiration_time, "%Y-%m-%dT%H:%M:%SZ") + datetime.timedelta(
            hours=8) - datetime.timedelta(minutes=10)

		# 容错，触发延迟1min后仍可正常执行
        self.__scheduler.add_job(self.__get_assumed_role, "date", args=[product, permission], run_date=trigger_time,
                                 id=refresh_assumerole_task, misfire_grace_time=60)

    @staticmethod
    def __translate_datarows(meta_to_table, datarows):
        """
        将数据行的元数据信息翻译为Table信息
        :param meta_to_table:
        :param datarows:
        :return:
        """
        result_rows = []
        for datarow in datarows:
            result_row = {}
            for column in datarow:
                if column not in meta_to_table:
                    continue
                tablecolumndef = meta_to_table.get(column)
                if tablecolumndef["type"] == "STRING":
                    result_row[tablecolumndef["name"]] = str(datarow[column])
                elif tablecolumndef["type"] == "BIGINT":
                    result_row[tablecolumndef["name"]] = None if datarow[column] == "null" else int(datarow[column])

            result_rows.append(result_row)

        return result_rows

    def __translate_filters(self, raw_filter: CompositeColumnCondition, table_to_meta: dict):
        """
        将过滤条件中的表字段翻译为元数据字段
        :param raw_filter:
        :param table_to_meta:
        :return:
        """
        if raw_filter is None:
            if self.__authtype == Consts.AUTHTYPE_APPLICATION:
                # 第三方应用授权，只能获取指定用户的数据
                return SingleColumnCondition(column_name="healthId", column_value=self.__healthId,
                                             comparator=ComparatorType.EQUAL)
            else:
                return None

        if type(raw_filter) == SingleColumnCondition:
            # 单个过滤条件，直接翻译并返回
            singlecolumncondition = SingleColumnCondition(table_to_meta.get(raw_filter.get_column_name()),
                                                          str(raw_filter.get_column_value()),
                                                          raw_filter.get_comparator())
            if self.__authtype == Consts.AUTHTYPE_APPLICATION:
                # 第三方应用授权，只能获取指定用户的数据
                condition = CompositeColumnCondition(LogicalOperator.AND)
                condition.add_sub_condition(SingleColumnCondition(column_name="healthId", column_value=self.__healthId,
                                                                  comparator=ComparatorType.EQUAL))
                condition.add_sub_condition(singlecolumncondition)
                return condition
            else:
                return singlecolumncondition

        # 多个的话，需要递归
        translated_condition = CompositeColumnCondition(raw_filter.combinator)
        for sub_condition in raw_filter.sub_conditions:
            self.__transalte_filter_recursively(sub_condition, translated_condition, table_to_meta)

        if self.__authtype == Consts.AUTHTYPE_APPLICATION:
            # 第三方应用授权，只能获取指定用户的数据
            condition = CompositeColumnCondition(LogicalOperator.AND)
            condition.add_sub_condition(SingleColumnCondition(column_name="healthId", column_value=self.__healthId,
                                                              comparator=ComparatorType.EQUAL))
            condition.add_sub_condition(translated_condition)
            return condition
        else:
            return translated_condition

    def __transalte_filter_recursively(self, raw_filter: ColumnCondition, parentfilter: ColumnCondition,
                                       table_to_meta: dict):
        """
        递归翻译过滤器
        :param raw_filter:
        :param parentfilter:
        :param table_to_meta:
        :return:
        """
        if raw_filter is None:
            return

        if type(raw_filter) == SingleColumnCondition:
            """
            如果是简单过滤，则直接添加
            """
            single_condition = raw_filter

            if table_to_meta.get(single_condition.get_column_name()) is None:
                raise CustomException(ErrorCodes.ERR_CODE_TABLE_FIELD_NOT_EXIST,
                                      "表字段 %s 不存在，请检查研究管理平台中的表字段配置" % single_condition.get_column_name())

            condition = SingleColumnCondition(table_to_meta.get(single_condition.get_column_name()),
                                              str(single_condition.get_column_value()),
                                              single_condition.get_comparator())

            parentfilter.add_sub_condition(condition)
        elif type(raw_filter) == CompositeColumnCondition:
            """
            复合过滤，则继续递归
            """
            composite_condition = raw_filter
            condition = CompositeColumnCondition(composite_condition.combinator)

            parentfilter.add_sub_condition(condition)

            if composite_condition.sub_conditions is not None and len(composite_condition.sub_conditions) > 0:
                for sub_condition in composite_condition.sub_conditions:
                    self.__transalte_filter_recursively(sub_condition, condition, table_to_meta)

    def __wrap_header_with_token(self, request_header):
        """
        交互后台接口，header都需要这个token
        :param request_header:
        :return:
        """
        if self.__sessionToken is None or self.__sessionToken == "":
            raise CustomException(ErrorCodes.ERR_CODE_NOT_AUTHED, "未通过授权！")

        if self.__authtype == Consts.AUTHTYPE_MEMBER:
            request_header["Bridge-Session"] = self.__sessionToken
        elif self.__authtype == Consts.AUTHTYPE_APPLICATION:
            request_header["Bridge-Application-Session"] = self.__sessionToken

    def _register(self, observer):
        """
        注册观察者
        :param observer:
        :return:
        """
        self.__observors.append(observer)

    def _remove(self, observer):
        """
        移除观察者
        :param observer:
        :return:
        """
        self.__observors.remove(observer)

    def _notify(self, change):
        """
        通知观察者
        :param change:
        :return:
        """
        for observer in self.__observors:
            observer.update(change)
