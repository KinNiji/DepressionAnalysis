#! /usr/bin/env python
# -*- coding: UTF-8 -*-

import functools


def inspect_project_switch(func):
    """
    装饰器：监听项目切换
    :param func:
    :return:
    """

    @functools.wraps(func)
    def impl(*args, **kwargs):
        # get caller class name
        class_name = args[0].__class__.__name__

        # get bridgeconfig from caller object
        bridge_config = getattr(args[0], "_" + class_name + "__bridgeConfig")

        # when project is switched, tell the server
        if getattr(bridge_config, "_" + bridge_config.__class__.__name__ + "__project_switched") is True:
            # get sessiontoken from req
            session_token = args[1].get_sessiontoken()
            # get projectcode from bridgeconfig
            new_project_code = bridge_config.get_projectcode()
            # get hiresearch server apis
            hiresearchdataservice = getattr(args[0], "_" + class_name + "__hiresearchdataservice")

            # tell the server
            hiresearchdataservice.switch_project(session_token, new_project_code)

            # reset flag
            setattr(bridge_config, "_" + bridge_config.__class__.__name__ + "__project_switched", False)

        # call the decorated func
        return func(*args, **kwargs)

    return impl
