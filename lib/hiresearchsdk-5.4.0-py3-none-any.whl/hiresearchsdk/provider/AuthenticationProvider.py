#! /usr/bin/env python
# -*- coding: UTF-8 -*-

import json
import time

from ..model import AuthRequest
from ..model import RefreshAuthRequest
from ..model import AuthResponse
from ..config import BridgeConfig, HttpClientConfig
from ..provider import ApiClientProvider
from ..utilities import HttpHelper, Utils


class AuthenticationProvider(object):
    def __init__(self, bridgeconfig: BridgeConfig, httpclientconfig: HttpClientConfig,
                 apiclientprovider: ApiClientProvider):
        self.__bridgeConfig = bridgeconfig
        self.__httpClientConfig = httpclientconfig
        self.__apiClientProvider = apiclientprovider

        self.__timeout = None
        if self.__httpClientConfig is not None:
            self.__timeout = (self.__httpClientConfig.get_connect_timeout(), self.__httpClientConfig.get_read_timeout())

    def auth(self, req: AuthRequest) -> any:
        Utils.assert_not_none(req, "req")

        return self.exchangeToken(req)

    def refreshAuth(self, req: RefreshAuthRequest):
        Utils.assert_not_none(req, "req")

        return self.refreshToken(req)

    def exchangeToken(self, req: AuthRequest):
        request_header = {}
        request_header["Project-Code"] = self.__bridgeConfig.get_projectcode()
        request_header["User-Agent"] = self.__bridgeConfig.get_useragent()

        request_body = {
            "accessKey": req.get_accessKey(),
            "secretKey": req.get_secretKey()
        }

        result = HttpHelper.post(self.__apiClientProvider.prepare_request(),
                                 HttpHelper.build_http_url(self.__bridgeConfig.get_baseurl(),
                                                           BridgeConfig.URL_AUTH),
                                 request_body, request_header=request_header, timeout=self.__timeout)

        setattr(self.__bridgeConfig, "_" + self.__bridgeConfig.__class__.__name__ + "__project_switched", True)

        login_ret = json.loads(result, encoding="utf8")
        return AuthResponse(login_ret['accessToken'], login_ret['refreshToken'], login_ret['accessTokenDurationInMillis'], login_ret['refreshTokenDurationInMillis'])

    def refreshToken(self, req: RefreshAuthRequest):
        request_header = {}
        request_header["Project-Code"] = self.__bridgeConfig.get_projectcode()
        request_header["User-Agent"] = self.__bridgeConfig.get_useragent()

        request_body = {
            "accessKey": req.get_accessKey(),
            "secretKey": req.get_secretKey(),
            "refreshToken": req.get_refreshToken()
        }

        result = HttpHelper.post(self.__apiClientProvider.prepare_request(),
                                 HttpHelper.build_http_url(self.__bridgeConfig.get_baseurl(),
                                                           BridgeConfig.URL_AUTH_REFRESH),
                                 request_body, request_header=request_header, timeout=self.__timeout)

        setattr(self.__bridgeConfig, "_" + self.__bridgeConfig.__class__.__name__ + "__project_switched", True)

        login_ret = json.loads(result, encoding="utf8")
        return AuthResponse(login_ret['accessToken'], login_ret['refreshToken'], login_ret['accessTokenDurationInMillis'], login_ret['refreshTokenDurationInMillis'])
