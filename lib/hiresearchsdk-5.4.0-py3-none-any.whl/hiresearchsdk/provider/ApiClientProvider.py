#! /usr/bin/env python
# -*- coding: UTF-8 -*-
import requests

from ..config import HttpClientConfig


class ApiClientProvider(object):
    """
    提供客户端请求对象
    """

    def __init__(self, httpclientconfig: HttpClientConfig = None):
        self.__httpClientConfig = httpclientconfig

    def prepare_request(self):
        """
        获取一个请求
        :return:
        """

        if self.__httpClientConfig is None or self.__httpClientConfig.is_retry_on_fail() is not True:
            return requests

        session = requests.Session()

        adapter = self.__httpClientConfig.get_httpadapter()
        session.mount('http://', adapter)
        session.mount('https://', adapter)

        return session
