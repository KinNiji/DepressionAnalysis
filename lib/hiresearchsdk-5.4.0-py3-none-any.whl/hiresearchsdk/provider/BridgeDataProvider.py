#! /usr/bin/env python
# -*- coding: UTF-8 -*-

from .adapter import AliyunDataAdapterImpl
from .decorator import inspect_project_switch
from ..config import BridgeConfig, HttpClientConfig
from ..model import GetAttachmentRequest, UploadObjectRequest, GetFileRequest, \
    ListObjectRequest, ListObjectResponse
from ..model.questionnaire import GetQuestionnaireByNameRequest
from ..model.table import CreateTableRequest, CreateTableResult, SearchTableDataRequest, \
    WriteTableDataRequest
from ..provider import ApiClientProvider
from ..service import HiResearchDataService


class BridgeDataProvider(object):
    def __init__(self, bridgeconfig: BridgeConfig, httpclientconfig: HttpClientConfig,
                 apiclientprovider: ApiClientProvider):
        self.__bridgeConfig = bridgeconfig
        self.__data_adapter = AliyunDataAdapterImpl(bridgeconfig, httpclientconfig, apiclientprovider)
        self.__hiresearchdataservice = HiResearchDataService(bridgeconfig, httpclientconfig, apiclientprovider)

    @inspect_project_switch
    def create_study_table(self, req: CreateTableRequest) -> CreateTableResult:
        """
        创建研究数据表
        :param req:
        :return:
        """
        return self.__hiresearchdataservice.create_study_table(req)

    @inspect_project_switch
    def get_questionnaire_by_name(self, req: GetQuestionnaireByNameRequest) -> any:
        """
        根据问卷名称获取问卷信息
        :param req:
        :return:
        """

        return self.__hiresearchdataservice.get_questionnaire_by_name(req)

    @inspect_project_switch
    def query_table_data(self, req: SearchTableDataRequest, callback: any):
        """
        查询研究数据表数据
        :param req:
        :param callback: 回调函数，用于处理数据行
        :return:
        """
        return self.__hiresearchdataservice.query_table_data(req, callback)

    @inspect_project_switch
    def write_table_data(self, req: WriteTableDataRequest):
        """
        写入研究数据表数据
        :param req:
        :return:
        """
        return self.__hiresearchdataservice.write_table_data(req)

    @inspect_project_switch
    def get_attachment(self, req: GetAttachmentRequest) -> any:
        """
        获取附件内容
        :param req:
        :return:
        """
        return self.__data_adapter.resolve_attachment(req)

    @inspect_project_switch
    def get_file(self, req: GetFileRequest) -> any:
        """
        获取文件内容
        :param req:
        :return:
        """
        return self.__data_adapter.get_file(req)

    @inspect_project_switch
    def list_objects(self, req: ListObjectRequest) -> ListObjectResponse:
        """
        列举指定目录下的文件、目录列表
        本API为分页API，单次返回最大1000条数据，如果超出一千条，API返回参数会包含next_marker作为分页参数，再次调用本API并传入marker即可
        :param req:
        :return:
        """
        return self.__data_adapter.list_objects(req)

    @inspect_project_switch
    def upload_file(self, req: UploadObjectRequest) -> str:
        """
        压缩文件或目录为zip，然后上传文件管理；上传文件时，文件是否压缩是可选项，默认不压缩，通过入参的file_need_zip控制
        :param req:
        :return:
        """
        return self.__data_adapter.upload_file(req)
