#! /usr/bin/env python
# -*- coding: UTF-8 -*-

from abc import ABCMeta, abstractmethod

from ...model import GetAttachmentRequest, UploadObjectRequest, ListObjectRequest, ListObjectResponse


class DataAdapter(metaclass=ABCMeta):
    @abstractmethod
    def resolve_attachment(self, req: GetAttachmentRequest) -> any:
        pass

    @abstractmethod
    def list_objects(self, req: ListObjectRequest) -> ListObjectResponse:
        pass

    @abstractmethod
    def upload_file(self, req: UploadObjectRequest) -> str:
        pass
