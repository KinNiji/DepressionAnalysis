#! /usr/bin/env python
# -*- coding: UTF-8 -*-


import base64
import datetime
import hashlib
import io
import json
import os
import re
import sys
import zipfile

from ..DataAdapter import DataAdapter
from ....config import BridgeConfig, HttpClientConfig
from ....exceptions import ErrorCodes, CustomException
from ....model import AssumedAuthInfo, GetAttachmentRequest, UploadObjectRequest, GetFileRequest, \
    ListObjectRequest, ListObjectResponse
from ....model.files import ObjectMeta
from ....provider import ApiClientProvider
from ....service import HiResearchDataService
from ....utilities import Logger, HttpHelper, Utils, ObsHelper, Consts, AESCBC, ZipHelper


class AliyunDataAdapterImpl(DataAdapter):
    def __init__(self, bridgeconfig: BridgeConfig, httpclientconfig: HttpClientConfig,
                 apiclientprovider: ApiClientProvider):
        self.__bridgeConfig = bridgeconfig
        self.__httpClientConfig = httpclientconfig
        self.__apiClientProvider = apiclientprovider

        self.__timeout = None
        if self.__httpClientConfig is not None:
            self.__timeout = (self.__httpClientConfig.get_connect_timeout(), self.__httpClientConfig.get_read_timeout())

        self.__hiresearchdataservice = HiResearchDataService(bridgeconfig, httpclientconfig, apiclientprovider)

        # 产品名称
        self.__productname_tablestore = BridgeConfig.PRODUCT_ALIYUN_TABLESTORE
        self.__productname_oss = BridgeConfig.PRODUCT_ALIYUN_OSS

        # 缓存授权信息
        self.__product_to_authed = {}
        # 获取附件用的桶名
        self.__download_bucket_name = None
        # 上传数据用的bucket名称
        self.__upload_bucket_name = None

        self.__zip_helper = ZipHelper()

    def resolve_attachment(self, req: GetAttachmentRequest):
        """
        获取附件内容接口，输出到指定目录下
        :param req:
        :return:
        """
        _, extras = self.__auth_oss_read(req.get_sessiontoken(), {"objectKey": req.get_attachment_handler(), "tableId": req.get_table_id()})

        cloud_type = extras.get("cloudType")
        if cloud_type == Consts.CLOUDTYPE_HIS:
            try:
                real_content = HttpHelper.get_file(self.__apiClientProvider.prepare_request(), extras.get("url"), None,
                                              timeout=self.__timeout, stream=False).content
            except Exception as err:
                Logger().error("Failed to download file，" + ErrorCodes.get_err_msg(err))
                raise CustomException(ErrorCodes.ERR_CODE_CLOUD_ERROR, "Failed to download file").with_traceback(
                    sys.exc_info()[2])
        else:
            content = self.__obs_attachment.get_object(req.get_attachment_handler())

            if extras['isExistInStudy'] is True:
                real_content = content
            else:
                # check signature
                sha256 = hashlib.sha256()
                sha256.update(content)
                real_signature = base64.encodebytes(sha256.digest())
                real_signature = re.compile('[\\x00-\\x08\\x0b-\\x0c\\x0e-\\x1f\n\r\t]').sub('', real_signature.decode())
                if real_signature != extras["contentSignature"]:
                    raise CustomException(ErrorCodes.ERR_CODE_ATTACHMENT_SIG_NOT_MATCH, "Invalid attachment !")

                # decrypt content
                real_content = AESCBC().decrypt_with_aes(content, extras["secret"], extras["ivParameter"].encode("utf8"))

        # unzip all files
        real_names = []
        with zipfile.ZipFile(io.BytesIO(real_content), "r") as myzip:
            names = myzip.namelist()
            for name in names:
                if name == "info.json":
                    # skip info.json
                    continue

                real_names.append(name)

                myzip.extract(name, req.get_output_folder())

        return real_names

    def get_file(self, req: GetFileRequest):
        """
        下载文件接口
        :param req:
        :return:
        """
        _, extras = self.__auth_oss_download(req.get_sessiontoken(), "/" + req.get_filepath(), req.get_target_projectCode())

        index_num = req.get_filepath().find("obs://")
        # from copypath
        if index_num >= 0:
            split_parts = req.get_filepath().split("/customuploads/")
            realpath = Consts.FILES_UPLOADS_PREFIX + split_parts[1]
        else:
            realpath = Consts.FILES_UPLOADS_PREFIX + req.get_filepath()

        cloud_type = extras.get("cloudType")
        if cloud_type == Consts.CLOUDTYPE_HIS:
            try:
                if req.get_output_path() is None:
                    return HttpHelper.get_file(self.__apiClientProvider.prepare_request(), extras.get("url"), None,
                                               timeout=self.__timeout, stream=False).content
                else:
                    # 指定了下载目录，启用流式下载
                    with HttpHelper.get_file(self.__apiClientProvider.prepare_request(), extras.get("url"), None,
                                             timeout=self.__timeout, stream=True) as raw:
                        raw.raise_for_status()
                        with open(req.get_output_path(), "wb+") as file:
                            for chunk in raw.iter_content(chunk_size=8192):
                                if chunk:  # filter out keep-alive new chunks
                                    file.write(chunk)
            except Exception as err:
                Logger().error("Failed to download file，" + ErrorCodes.get_err_msg(err))
                raise CustomException(ErrorCodes.ERR_CODE_CLOUD_ERROR, "Failed to download file").with_traceback(
                    sys.exc_info()[2])

        else:
            return self.__obs_reader.get_object(realpath)

    def list_objects(self, req: ListObjectRequest):
        """
        列举指定目录下的文件、目录
        :param req:
        :return:
        """
        object_metas = []

        _, extras = self.__auth_oss_list(req.get_sessiontoken(), "/" + req.get_objectpath(), req.get_target_projectCode())

        cloud_type = extras.get("cloudType")
        if cloud_type != Consts.CLOUDTYPE_HIS:
            realpath = Consts.FILES_UPLOADS_PREFIX + req.get_objectpath()

            ret_objects = self.__obs_reader.list_objects(realpath, req.get_marker())

            next_marker = ret_objects.marker

            for ret_object in ret_objects.body.contents:
                if ret_object.key == Consts.FILES_UPLOADS_PREFIX or ret_object.key == Consts.FILES_UPLOADS_PREFIX + req.get_objectpath():
                    continue

                object_meta = ObjectMeta(ret_object.key.replace(Consts.FILES_UPLOADS_PREFIX, "", 1),
                                         ret_object.key[len(ret_object.key) - 1] == "/",
                                         ret_object.size)
                object_metas.append(object_meta)
        else:
            next_marker = extras.get("nextMarker")

            for ret_object in extras.get("files"):
                if ret_object.get("name") == Consts.FILES_UPLOADS_PREFIX or ret_object.get(
                        "name") == Consts.FILES_UPLOADS_PREFIX + req.get_objectpath():
                    continue

                object_meta = ObjectMeta(ret_object.get("name").replace(Consts.FILES_UPLOADS_PREFIX, "", 1),
                                         not ret_object.get("isFile"),
                                         ret_object.get("size"))
                object_metas.append(object_meta)

        return ListObjectResponse(object_metas, next_marker)

    def upload_file(self, req: UploadObjectRequest):
        """
        上传文件或目录
        :param req:
        :return:
        """
        # 使用用户指定的路径
        cloudpath = Consts.FILES_UPLOADS_PREFIX + req.get_destpath()

        Logger.info("授权上传至%s" % cloudpath)
        _, extras = self.__auth_oss_upload(req.get_sessiontoken(), cloudpath)

        processed_objectpath, object_key, delete_after_upload = self.__try_archive_object(cloudpath,
                                                                                          req.get_objectpath(),
                                                                                          req.get_file_need_zip())

        Logger.info("开始上传")

        cloud_type = extras.get("cloudType")
        if cloud_type == Consts.CLOUDTYPE_HIS:
            try:
                with open(processed_objectpath, "rb") as upload_content:
                    HttpHelper.put(self.__apiClientProvider.prepare_request(), extras.get("url"),
                                   upload_content, timeout=self.__timeout, no_default_header=True)
                # create file
                url = HttpHelper.build_http_url(self.__bridgeConfig.get_baseurl(), BridgeConfig.URL_CREATE_FILE)

                request_header = {}
                Utils.wrap_header_with_token_v2(req.get_sessiontoken(), self.__bridgeConfig,
                                                request_header)
                request_body = {
                    "objectName": req.get_destpath()
                }

                HttpHelper.post(self.__apiClientProvider.prepare_request(), url, request_body, request_header,
                                         timeout=self.__timeout)
            except Exception as err:
                Logger().error("Failed to upload file，" + ErrorCodes.get_err_msg(err))
                raise CustomException(ErrorCodes.ERR_CODE_CLOUD_ERROR, "Failed to upload file").with_traceback(
                    sys.exc_info()[2])
        else:
            object_key, _ = self.__obs_uploader.put_object(processed_objectpath, object_key, delete_after_upload)
            # create file
            url = HttpHelper.build_http_url(self.__bridgeConfig.get_baseurl(), BridgeConfig.URL_CREATE_FILE)

            request_header = {}
            Utils.wrap_header_with_token_v2(req.get_sessiontoken(), self.__bridgeConfig,
                                            request_header)
            request_body = {
                "objectName": req.get_destpath()
            }

            HttpHelper.post(self.__apiClientProvider.prepare_request(), url, request_body, request_header,
                            timeout=self.__timeout)
        Logger.info("上传成功")

        return object_key.replace("customuploads/", "")

    def __try_archive_object(self, object_folder: str, object_localpath: str, file_need_zip: bool):
        """
        try archive file
        :param object_folder:
        :param object_localpath:
        :param file_need_zip:
        :return:
        """
        Logger.info("Start to zip file")
        if object_folder[len(object_folder) - 1] == "/":
            # generate a filename for auto-generated object_folder
            zipfile = r'output_' + Utils.generate_uuid() + ".zip"
            object_key = object_folder + zipfile
        else:
            # get filename from user-specified object_folder
            parts = object_folder.split("/")

            processed_parts = []
            for part in parts:
                if part != "":
                    processed_parts.append(part)
            zipfile = processed_parts[len(processed_parts) - 1] + ".zip"
            object_key = object_folder

        # folder must be zipped; file should be zipped with user option
        delete_after_upload = False
        processed_objectpath = object_localpath
        if os.path.isdir(object_localpath) or file_need_zip:
            self.__zip_helper.zip_file_path(object_localpath, zipfile)
            processed_objectpath = zipfile
            delete_after_upload = True

        return processed_objectpath, object_key, delete_after_upload

    def __auth_oss_read(self, sessiontoken, extends=None):
        """
        授权访问oss读取附件
        :param sessiontoken:
        :return:
        """
        return self.__refresh_temporary_auth(sessiontoken, self.__productname_oss,
                                             BridgeConfig.PERMISSION_READ_ATTACHMENTS,
                                             extends)

    def __auth_oss_download(self, sessiontoken, filepath, targetprojectCode):
        """
        授权访问oss读取普通文件
        :param sessiontoken:
        :param filepath:
        :return:
        """
        return self.__refresh_temporary_auth(sessiontoken, self.__productname_oss, BridgeConfig.PERMISSION_READ_FILES,
                                             {"filePath": filepath, "targetProjectCode": targetprojectCode})

    def __auth_oss_list(self, sessiontoken, filepath, targetprojectCode):
        """
        授权访问oss遍历存储对象列表
        :param sessiontoken:
        :param filepath:
        :return:
        """
        return self.__refresh_temporary_auth(sessiontoken, self.__productname_oss, BridgeConfig.PERMISSION_LIST_OBJECTS,
                                             {"filePath": filepath, "targetProjectCode": targetprojectCode})

    def __auth_oss_upload(self, sessiontoken, uploadpath):
        """
        授权访问oss读取上传路径
        :param sessiontoken:
        :return:
        """
        return self.__refresh_temporary_auth(sessiontoken, self.__productname_oss, BridgeConfig.PERMISSION_UPLOAD,
                                             {"filePath": uploadpath})

    def __refresh_temporary_auth(self, sessiontoken, product, permission, extends=None):
        """
        尝试按需刷新鉴权
        :param sessiontoken:
        :param product:
        :param permission:
        :param extends:
        :return:
        """
        auth_index = product + "_" + permission
        if product == self.__productname_tablestore and permission == BridgeConfig.PERMISSION_READ:
            auth_index = auth_index + "_" + extends["tableName"]

        if product == self.__productname_oss and (
                permission == BridgeConfig.PERMISSION_UPLOAD
                or permission == BridgeConfig.PERMISSION_READ_FILES
                or permission == BridgeConfig.PERMISSION_LIST_OBJECTS
                or permission == BridgeConfig.PERMISSION_READ_ATTACHMENTS):
            if permission == BridgeConfig.PERMISSION_UPLOAD:
                # 初始化oss上传，由于每次上传路径不同，需要重新授权
                extras = self.__get_assumed_role(sessiontoken, product, permission, extends)
                self.__upload_bucket_name = extras["bucketName"]

                if extras.get("cloudType") != Consts.CLOUDTYPE_HIS:
                    self.__obs_uploader = ObsHelper(self.__product_to_authed[auth_index].get_key(),
                                                    self.__product_to_authed[auth_index].get_secret(),
                                                    self.__product_to_authed[auth_index].get_securitytoken(),
                                                    self.__product_to_authed[auth_index].get_endpoint(),
                                                    self.__upload_bucket_name)
                return True, extras
            elif permission == BridgeConfig.PERMISSION_READ_FILES:
                # 初始化oss下载，由于每次上传路径不同，需要重新授权
                extras = self.__get_assumed_role(sessiontoken, product, permission, extends)
                self.__download_bucket_name = extras["bucketName"]

                if extras.get("cloudType") != Consts.CLOUDTYPE_HIS:
                    self.__obs_reader = ObsHelper(self.__product_to_authed[auth_index].get_key(),
                                                  self.__product_to_authed[auth_index].get_secret(),
                                                  self.__product_to_authed[auth_index].get_securitytoken(),
                                                  self.__product_to_authed[auth_index].get_endpoint(),
                                                  self.__download_bucket_name)
                return True, extras
            elif permission == BridgeConfig.PERMISSION_LIST_OBJECTS:
                # 初始化oss列举，由于每次上传路径不同，需要重新授权
                extras = self.__get_assumed_role(sessiontoken, product, permission, extends)
                self.__list_bucket_name = extras["bucketName"]

                if extras.get("cloudType") != Consts.CLOUDTYPE_HIS:
                    self.__obs_reader = ObsHelper(self.__product_to_authed[auth_index].get_key(),
                                                  self.__product_to_authed[auth_index].get_secret(),
                                                  self.__product_to_authed[auth_index].get_securitytoken(),
                                                  self.__product_to_authed[auth_index].get_endpoint(),
                                                  self.__list_bucket_name)
                return True, extras

            if permission == BridgeConfig.PERMISSION_READ_ATTACHMENTS:
                # 初始化oss读取
                extras = self.__get_assumed_role(sessiontoken, product, permission, extends)
                self.__attachments_bucket_name = extras["bucketName"]

                if extras.get("cloudType") != Consts.CLOUDTYPE_HIS:
                    self.__obs_attachment = ObsHelper(self.__product_to_authed[auth_index].get_key(),
                                                      self.__product_to_authed[auth_index].get_secret(),
                                                      self.__product_to_authed[auth_index].get_securitytoken(),
                                                      self.__product_to_authed[auth_index].get_endpoint(),
                                                      self.__attachments_bucket_name)

                return True, extras

        if auth_index in self.__product_to_authed and \
                not self.__product_to_authed[auth_index].is_expired():
            Logger().debug("%s权限无需刷新" % auth_index)
            return False

    def __get_assumed_role(self, sessiontoken, product, permission, extends):
        """
        获取产品临时授权
        :param sessiontoken:
        :param product:
        :param permission:
        :param extends:
        :return:
        """
        try:
            url = HttpHelper.build_http_url(self.__bridgeConfig.get_baseurl(), BridgeConfig.URL_ASSUMEROLE)

            request_header = {}
            Utils.wrap_header_with_token_v2(sessiontoken, self.__bridgeConfig,
                                            request_header)
            request_body = {
                "product": product,
                "permission": permission,
                "extends": extends
            }

            result = HttpHelper.post(self.__apiClientProvider.prepare_request(), url, request_body, request_header,
                                     timeout=self.__timeout)

            info_ret = json.loads(result, encoding="utf8")
        except Exception as err:
            Logger().error(product + "客户端刷新失败，" + ErrorCodes.get_err_msg(err))
            raise CustomException(ErrorCodes.ERR_CODE_NOT_AUTHED, "授权失败").with_traceback(
                sys.exc_info()[2])

        expiration_time = info_ret["expiration"]
        if expiration_time is None or expiration_time == "":
            # 没有超时时间，不去刷新
            return info_ret["extras"]

        # 超时时间与北京时间存在8效时滞后，所以加上8小时。减去5min是为了确保在失效前重新获取
        expiretime = datetime.datetime.strptime(expiration_time, "%Y-%m-%dT%H:%M:%SZ") + datetime.timedelta(
            hours=8) - datetime.timedelta(minutes=5)

        # ots读取需要特殊处理
        key = product + "_" + permission

        self.__product_to_authed[key] = AssumedAuthInfo(
            info_ret["internalEndpoint"],
            info_ret["accessKeyId"],
            info_ret["accessKeySecret"],
            info_ret["securityToken"], expiretime)

        return info_ret["extras"]
