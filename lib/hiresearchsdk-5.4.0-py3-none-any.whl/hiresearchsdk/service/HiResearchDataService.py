#! /usr/bin/env python
# -*- coding: UTF-8 -*-

import json
from urllib import parse

from ..config import BridgeConfig, HttpClientConfig
from ..model.questionnaire import GetQuestionnaireByNameRequest
from ..model.table import CreateTableRequest, CreateTableResult, TableField, SearchTableDataRequest, \
    WriteTableDataRequest
from ..provider import ApiClientProvider
from ..utilities import HttpHelper, Utils


class HiResearchDataService(object):
    """
    获取hiresearch数据的服务
    """

    def __init__(self, bridgeconfig: BridgeConfig, httpclientconfig: HttpClientConfig,
                 apiclientprovider: ApiClientProvider):
        self.__bridgeConfig = bridgeconfig
        self.__httpClientConfig = httpclientconfig
        self.__apiClientProvider = apiclientprovider

        self.__timeout = None
        if self.__httpClientConfig is not None:
            self.__timeout = (self.__httpClientConfig.get_connect_timeout(), self.__httpClientConfig.get_read_timeout())

    def switch_project(self, session_token: str, project_code: str):
        """
        切换项目
        :param session_token:
        :param project_code:
        :return:
        """
        url = HttpHelper.build_http_url(self.__bridgeConfig.get_baseurl(), self.__bridgeConfig.URL_SWITCHPROJECT)

        request_header = {
            "csrf-token": session_token
        }
        Utils.wrap_header_with_token_v2(session_token, self.__bridgeConfig,
                                        request_header)

        request_body = {
            "projectCode": project_code
        }

        HttpHelper.post(self.__apiClientProvider.prepare_request(), url, request_body, request_header,
                        timeout=self.__timeout)

    def create_study_table(self, req: CreateTableRequest):
        """
        创建研究数据表
        :param req:
        :return:
        """
        url = HttpHelper.build_http_url(self.__bridgeConfig.get_baseurl(), self.__bridgeConfig.URL_CREATETABLE)

        request_header = {}
        Utils.wrap_header_with_token_v2(req.get_sessiontoken(), self.__bridgeConfig,
                                        request_header)

        # create an copy of user input
        contains_uniqueid = False
        fields = []
        for field_info in req.get_field_list():
            field_name = field_info.get_name().lower()
            if field_name == "uniqueid":
                contains_uniqueid = True

            fields.append({
                "name": field_name,
                "type": field_info.get_type(),
                "description": field_info.get_description(),
            })

        if not contains_uniqueid:
            # if not contains uniqueid, add one
            fields.append({
                "name": "uniqueid",
                "type": TableField.TYPE_STRING,
                "description": "Reserved field: uniqueid. Created from python sdk",
            })

        request_body = {
            "name": req.get_table_name(),
            "description": req.get_table_comment(),
            "fieldInfos": fields
        }

        result = HttpHelper.post(self.__apiClientProvider.prepare_request(), url, request_body, request_header,
                                 timeout=self.__timeout)
        info_ret = json.loads(result, encoding="utf8")
        table_id = info_ret["tableId"]

        create_result = CreateTableResult(table_id)

        return create_result

    def get_questionnaire_by_name(self, req: GetQuestionnaireByNameRequest):
        """
        根据问卷名称获取问卷信息
        :param req:
        :return:
        """
        url = HttpHelper.build_http_url(self.__bridgeConfig.get_baseurl(),
                                        self.__bridgeConfig.URL_GETQUESTIONNAIREBYNAME)

        request_header = {}
        Utils.wrap_header_with_token_v2(req.get_sessiontoken(), self.__bridgeConfig,
                                        request_header)

        result = HttpHelper.get(self.__apiClientProvider.prepare_request(), url.format(parse.quote(req.get_name())),
                                request_header,
                                timeout=self.__timeout)

        info_ret = json.loads(result, encoding="utf8")

        return info_ret

    def query_table_data(self, req: SearchTableDataRequest, callback: any):
        """
        查询研究数据表数据
        :param req:
        :param callback: 回调函数，用于处理数据行
        :return:
        """
        has_group_by_fields = False
        if req.aggregationInfo:
            if req.aggregationInfo.groupByFields:
                has_group_by_fields = True

        has_aggregation_operation = False
        if req.aggregationInfo:
            if req.aggregationInfo.aggregations:
                has_aggregation_operation = True

        url = HttpHelper.build_http_url(self.__bridgeConfig.get_baseurl(),
                                        self.__bridgeConfig.URL_SEARCHTABLEDATA)

        request_header = {}
        Utils.wrap_header_with_token_v2(req.get_sessiontoken(), self.__bridgeConfig,
                                        request_header)

        # 查询第一页
        request_body = Utils.dumps(req)
        result = HttpHelper.post(self.__apiClientProvider.prepare_request(), url.format(parse.quote(req.tableId)),
                                 request_body,
                                 request_header,
                                 timeout=self.__timeout)

        info_ret = json.loads(result, encoding="utf8")

        try:
            if req.aggregationInfo:
                # 聚合查询
                if has_group_by_fields:
                    # 有分组字段
                    if info_ret["aggregations"] is not None:
                        if info_ret["aggregations"]["afterKey"] is not None:
                            # 需后续查询
                            while info_ret["aggregations"]["afterKey"] is not None:
                                if has_aggregation_operation:
                                    callback(info_ret["aggregations"]["results"], -1)
                                else:
                                    keys = []
                                    for item in info_ret["aggregations"]["results"]:
                                        keys.append(item["key"])
                                    callback(keys, -1)
                                req.aggregationInfo.cursor = json.dumps((info_ret["aggregations"]["afterKey"]))
                                request_body = Utils.dumps(req)
                                result = HttpHelper.post(self.__apiClientProvider.prepare_request(),
                                                         url.format(req.tableId),
                                                         request_body,
                                                         request_header,
                                                         timeout=self.__timeout)
                                info_ret = json.loads(result, encoding="utf8")
                        else:
                            callback(info_ret["aggregations"]["results"], -1)
                    else:
                        callback([], 0)
                else:
                    # 无分组字段
                    if info_ret["aggregations"] is not None:
                        temp = list()
                        temp.append(info_ret["aggregations"])
                        callback(temp, -1)
                    else:
                        callback([], -1)
            else:
                # 非聚合查询
                if info_ret["total"] == 0:
                    callback([], 0)
                else:

                    # 是否需要限制查询数据条数
                    limit_results = True if req.giveUpWhenMoreThan is not None and req.giveUpWhenMoreThan > 0 else False
                    # 已处理的数据条数
                    processed_results_cnt = 0

                    while len(info_ret["results"]) > 0 and info_ret["total"] > 0:
                        if limit_results:
                            # 已处理数据条数超出限制条数，则跳出循环
                            next_processed_results_cnt = processed_results_cnt + len(info_ret["results"])
                            if next_processed_results_cnt > req.giveUpWhenMoreThan:
                                callback(info_ret["results"][:req.giveUpWhenMoreThan - processed_results_cnt],
                                         info_ret["total"])
                                break
                            processed_results_cnt = next_processed_results_cnt

                        # 调用用户回调函数
                        callback(info_ret["results"], info_ret["total"])

                        # 查询后续页
                        request_body = json.dumps({
                            "tableId": req.tableId,
                            "scrollId": info_ret["scrollId"]
                        })
                        result = HttpHelper.post(self.__apiClientProvider.prepare_request(),
                                                 url.format(req.tableId),
                                                 request_body,
                                                 request_header,
                                                 timeout=self.__timeout)

                        info_ret = json.loads(result, encoding="utf8")
        finally:
            # 清理会话id
            if info_ret.get("scrollId") is not None:
                self.__clear_scroll(req.get_sessiontoken(), info_ret["scrollId"])

    def write_table_data(self, req: WriteTableDataRequest):
        """
        写入研究数据表数据，uniqueid相同时，覆盖
        :param req: 写入请求
        :return:
        """
        url = HttpHelper.build_http_url(self.__bridgeConfig.get_baseurl(),
                                        self.__bridgeConfig.URL_WRITETABLEDATA)

        request_header = {}
        Utils.wrap_header_with_token_v2(req.get_sessiontoken(), self.__bridgeConfig,
                                        request_header)

        request_body = {
            "tableId": req.tableId,
            "dataRows": req.dataRows
        }

        HttpHelper.post(self.__apiClientProvider.prepare_request(), url,
                        request_body,
                        request_header,
                        timeout=self.__timeout)

    def __clear_scroll(self, session_token: str, scroll_id: str):
        """
        清理搜索会话
        :param session_token:
        :param scroll_id:
        :return:
        """
        url = HttpHelper.build_http_url(self.__bridgeConfig.get_baseurl(),
                                        self.__bridgeConfig.URL_CLEARSCROLL)
        request_header = {}
        Utils.wrap_header_with_token_v2(session_token, self.__bridgeConfig,
                                        request_header)

        request_body = {
            "scrollId": scroll_id
        }

        HttpHelper.post(self.__apiClientProvider.prepare_request(),
                        url,
                        request_body,
                        request_header,
                        timeout=self.__timeout)
